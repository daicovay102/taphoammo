const Users = require('../../database/entities/Users');
const ResponseModel = require('../models/ResponseModel');
const { USER_ROLE, ORDER_STATUS, TRANSACTION_TYPE, TRANSACTION_STATUS } = require('../../constants/enum');
const Transactions = require('../../database/entities/Transactions');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const { randomString } = require('../../utilities/random');
const PagedModel = require('../models/PagedModel');
const { Types } = require('mongoose');

async function editBalance(req, res) {
    try {
        const { userId, amount } = req.body;
        const newAmount = Number.parseInt(amount);
        if (req.role !== USER_ROLE.Admin) {
            return res.json(new ResponseModel(-1, 'BAN KHONG CO QUYEN!', null));
        }
        const user = await Users.findById(userId, { _id: 1, balance: 1 });
        if (!user) {
            return res.json(new ResponseModel(-1, 'KHONG TIM THAY USER', null));
        }
        // kiem tra rut tien
        if (newAmount < 0 && user.balance - Math.abs(newAmount) < 0) {
            return res.json(new ResponseModel(-1, 'KHONG DU SO DU!', null));
        }

        let newUser;
        const session = await Users.startSession();
        session.startTransaction();
        try {
            const updatedUser = await Users.findByIdAndUpdate(userId, { $inc: { balance: Number.parseInt(amount) } }, {
                session,
                new: true
            });
            await Transactions.create([
                {
                    adminId: req.userId,
                    userId,
                    value: newAmount,
                    type: newAmount > 0 ? TRANSACTION_TYPE.NAP_TIEN : TRANSACTION_TYPE.RUT_TIEN
                },
            ], { session });
            await session.commitTransaction();
            newUser = updatedUser;
        } catch (error) {
            await session.abortTransaction();
        } finally {
            await session.endSession();
        }

        if (newUser) {
            return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'NAP RUT TIEN THANH CONG', {
                id: newUser._id,
                email: newUser.email,
                role: newUser.role,
                userName: newUser.userName,
                phoneNumber: newUser.phoneNumber,
                avatar: newUser.avatar,
                fullName: newUser.fullName,
                balance: newUser.balance
            }));
        } else {
            res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, 'NAP RUT TIEN THAT BAI', null));
        }
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }

}

const createDepositCodeAndCheckDuplicate = async () => {
    const code = randomString(15);
    const isExist = await Transactions.findOne({ depositCode: code });
    if (!isExist) {
        return code;
    } else {
        await createDepositCodeAndCheckDuplicate();
    }
};

async function createDepositCode(req, res) {
    try {
        const userId = req.userId;
        const { amount } = req.body;
        const user = await Users.findById(userId, { _id: 1, balance: 1 });
        if (!user) {
            return res.json(new ResponseModel(-1, 'KHONG TIM THAY USER', null));
        }
        const code = await createDepositCodeAndCheckDuplicate();
        await Transactions.create([
            {
                userId,
                value: amount,
                type: TRANSACTION_TYPE.NAP_TIEN,
                depositCode: code,
                status: TRANSACTION_STATUS.PENDING
            },
        ]);
        return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'TAO MA NAP TIEN THANH CONG', { code }));
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

async function confirmDepositWithCode(req, res) {
    try {
        const { code } = req.body;
        if (req.role !== USER_ROLE.Admin) {
            return res.json(new ResponseModel(-1, 'BAN KHONG CO QUYEN!', null));
        }
        const transaction = await Transactions.findOne({ depositCode: code, status: TRANSACTION_STATUS.PENDING });
        if (!transaction) {
            return res.json(new ResponseModel(-1, 'MA NAP TIEN SAI!', null));
        }
        const user = await Users.findById(transaction.userId, { _id: 1, balance: 1 });
        if (!user) {
            return res.json(new ResponseModel(-1, 'KHONG TIM THAY USER', null));
        }

        let newUser;
        const session = await Users.startSession();
        session.startTransaction();
        try {
            const updatedUser = await Users.findByIdAndUpdate(transaction.userId, { $inc: { balance: Number.parseInt(transaction.value) } }, {
                session,
                new: true
            });
            await Transactions.findByIdAndUpdate(transaction._id, {
                $set: {
                    adminId: req.userId,
                    status: TRANSACTION_STATUS.COMPLETE
                }
            }, { session });
            await session.commitTransaction();
            newUser = updatedUser;
        } catch (error) {
            await session.abortTransaction();
        } finally {
            await session.endSession();
        }

        if (newUser) {
            return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'NAP TIEN THANH CONG', {
                id: newUser._id,
                email: newUser.email,
                role: newUser.role,
                userName: newUser.userName,
                phoneNumber: newUser.phoneNumber,
                avatar: newUser.avatar,
                fullName: newUser.fullName,
                balance: newUser.balance
            }));
        } else {
            res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, 'NAP TIEN THAT BAI', null));
        }
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

async function getWithdrawHistories(req, res) {
    try {
        return res.json(await getPaging(TRANSACTION_TYPE.RUT_TIEN, req.query));
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

async function getDepositHistories(req, res) {
    try {
        return res.json(await getPaging(TRANSACTION_TYPE.NAP_TIEN, req.query));
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

async function getPaging(type, body) {
    const pageSize = Number.parseInt(body.pageSize) || 10;
    const pageIndex = Number.parseInt(body.pageIndex) || 1;
    const { userId, status } = body;
    const filter = [
        { type },
        ...(userId ? [{ userId: new Types.ObjectId(userId) }] : []),
        ...(status ? [{ status: Number.parseInt(status) }] : [])
    ];
    const [data, count] = await Promise.all([
        Transactions.aggregate([
            { $match: { $and: filter } },
            { $sort: { createdAt: -1 } },
            { $skip: pageSize * pageIndex - pageSize },
            { $limit: pageSize },
            {
                $lookup: {
                    from: 'users',
                    localField: 'userId',
                    foreignField: '_id',
                    as: 'user',
                    pipeline: [{
                        $project: {
                            _id: 1,
                            email: 1,
                            fullName: 1,
                            userName: 1,
                            role: 1,
                            phoneNumber: 1,
                            avatar: 1
                        }
                    }]
                }
            },
            { $unwind: { path: '$user', preserveNullAndEmptyArrays: false } }
        ]),
        Transactions.count({ $and: filter })
    ]);
    return new PagedModel(pageIndex, pageSize, count, data);
}

async function userWithdraw(req, res) {
    try {
        const { amount } = req.body;
        const userId = req.userId;
        const newAmount = -Number.parseInt(amount);
        const user = await Users.findById(userId, { _id: 1, balance: 1 });
        if (!user) {
            return res.json(new ResponseModel(-1, 'KHONG TIM THAY USER', null));
        }
        // kiem tra rut tien
        if (user.balance - Math.abs(newAmount) < 0) {
            return res.json(new ResponseModel(-1, 'KHONG DU SO DU!', null));
        }

        let newUser;
        const session = await Users.startSession();
        session.startTransaction();
        try {
            const updatedUser = await Users.findByIdAndUpdate(userId, { $inc: { balance: newAmount } }, {
                session,
                new: true
            });
            await Transactions.create([
                {
                    userId,
                    value: newAmount,
                    type: TRANSACTION_TYPE.RUT_TIEN,
                    status: TRANSACTION_STATUS.PENDING
                },
            ], { session });
            await session.commitTransaction();
            newUser = updatedUser;
        } catch (error) {
            await session.abortTransaction();
        } finally {
            await session.endSession();
        }

        if (newUser) {
            return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'TAO LENH RUT TIEN THANH CONG', {
                id: newUser._id,
                email: newUser.email,
                role: newUser.role,
                userName: newUser.userName,
                phoneNumber: newUser.phoneNumber,
                avatar: newUser.avatar,
                fullName: newUser.fullName,
                balance: newUser.balance
            }));
        } else {
            res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, 'TAO LENH RUT TIEN THAT BAI', null));
        }
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

async function changeTractionStatus(req, res) {
    try {
        const { status, id } = req.body;
        await Transactions.findByIdAndUpdate(id, { $set: { status, adminId: req.userId } });
        return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'UPDATE TRANG THAI TIEN THANH CONG', null));
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

module.exports = {
    editBalance,
    createDepositCode,
    confirmDepositWithCode,
    getDepositHistories,
    getWithdrawHistories,
    userWithdraw,
    changeTractionStatus
};
