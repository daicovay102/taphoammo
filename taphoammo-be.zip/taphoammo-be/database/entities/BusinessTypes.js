require('../database');
const mongoose = require('mongoose');
const slug = require('mongoose-slug-generator');
mongoose.plugin(slug);
const { Schema } = mongoose;

let business_typeSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    name: {
        type: String,
        unique: true,
        required: true
    },
    slug: {
        type: String,
        slug: 'name',
        unique: true
    },
    status: {
        type: Number,
        default: 1
    }
}, {
    versionKey: false,
    timestamps: true
});

module.exports = mongoose.model('Business_types', business_typeSchema);
