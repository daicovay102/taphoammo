const shopEvaluationService = require('../services/shopEvaluationService');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const ResponseModel = require('../models/ResponseModel');
const PagedModel = require('../models/PagedModel');
const orderService = require('../services/orderService');
const moment = require('moment');

const insert = async (req, res) => {
    try {
        const { shopId } = req.body;
        const isHaveOrder = await orderService.getOne({ shopId, buyerId: req.userId });
        if (!isHaveOrder) {
            return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Must have order of this shop!', null));
        }
        const isExist = await shopEvaluationService.getOne({ createdBy: req.userId });
        if (isExist) {
            return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'You have review this shop before', null));
        }
        const result = await shopEvaluationService.insert(req.body, req.userId);
        return res.json(new ResponseModel(HTTP_STATUS.OK, 'Create shop evaluation success', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const getById = async (req, res) => {
    try {
        const result = await shopEvaluationService.getById(req.params.id);
        return res.json(new ResponseModel(HTTP_STATUS.OK, 'Get shop evaluation success', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const getAll = async (req, res) => {
    try {
        const reviews = await shopEvaluationService.getAll();
        return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'Get all shop evaluation success', reviews));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getPaging = async (req, res) => {
    try {
        const { pageIndex, pageSize, count, data } = await shopEvaluationService.getPaging(req.query);
        return res.json(new PagedModel(pageIndex, pageSize, count, data));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const update = async (req, res) => {
    try {
        const { id } = req.body;
        const review = await shopEvaluationService.getById(id);
        if (!review) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Shop evaluation not found', null));
        } else {
            if (!moment(new Date()).isBefore(moment(review.createdAt).add(1, 'days')) || review.createdBy.toString() !== req.userId.toString()) {
                return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Can not edit this review', null));
            }
            const result = await shopEvaluationService.update(id, req.body);
            res.json(new ResponseModel(1, 'Update shop evaluation success', result));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }

};

const deleteById = async (req, res) => {
    try {
        const review = await shopEvaluationService.getById(req.params.id);
        if (!review) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Shop evaluation not found', null));
        } else {
            if (!moment(new Date()).isBefore(moment(review.createdAt).add(1, 'days'))) {
                return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Can not delete this review', null));
            }
            const result = await shopEvaluationService.deleteById(req.params.id, req.userId);
            res.json(new ResponseModel(1, 'Delete shop evaluation success', result));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

module.exports = { insert, getById, getAll, getPaging, update, deleteById };