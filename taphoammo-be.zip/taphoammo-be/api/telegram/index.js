const userService = require('./../services/userService');
const Users = require('./../../database/entities/Users');
require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');

//https://telegram.me/Taphoammo2023Bot?start=userId
const BotTelegram = new TelegramBot(process.env.TOKEN_TELEGRAM, { polling: true });
BotTelegram.on('message', async (msg) => { // in group enter /start
    const text = msg.text.split(' ');
    if (text[0] == '/start') {
        const userId = text[1];
        const chatId = msg.chat.id;
        await userService.updateChatIdTelegram(userId, 1, chatId);
    }
});
exports.sendMessage = async (userId, message) => {
    const user = await Users.findOne({ _id: userId });
    if (user && user.telegram.status == 1) {
        const groupPush = user.telegram.group_id;
        await BotTelegram.sendMessage(groupPush, `Message from ${user.userName}:\n ${message}`);
    }
};