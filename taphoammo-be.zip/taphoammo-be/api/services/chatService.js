const Chats = require('../../database/entities/Chats');
const Users = require('../../database/entities/Users');
const telegram = require('../telegram');

const insert = async (payload, userId) => {
    const dataInsert = { ...payload, createdBy: userId };
    const chat = new Chats(dataInsert);
    return await chat.save();
};

const message = async (payload, userId) => {

    const chat = await Chats.findOne({ _id: payload.chatId });
    if (chat) {
        chat.messages.push({
            UserSend: userId,
            message: payload.message,
            time: new Date()
        });
        await chat.save();
        const userTo = chat.UserTo == userId ? chat.createdBy : chat.UserTo;

        // push notification telegram
        await telegram.sendMessage(userTo, payload.message);

        return chat;
    } else {
        return false;
    }
};

const getAll = async (userId) => {
    return Chats.find(
        { '$or': [{ 'createdBy': userId }, { 'UserTo': userId }] }
    ).populate('createdBy UserTo', { 'userName': 1, 'avatar': 1 }).sort({ createdAt: 'desc' });
};

module.exports = {
    insert,
    getAll,
    message
};