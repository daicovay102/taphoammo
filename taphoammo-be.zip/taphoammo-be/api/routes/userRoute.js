const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const {
    registerValidator,
    loginValidator,
    refreshTokenValidator,
    accessTokenValidator,
    accessTokenAdminValidator,
    insertUserValidator,
    updateUserValidator,
    forgotPasswordValidator,
    verifyForPasswordTokenValidator,
    resetPasswordValidator,
    changePasswordValidator,
    verify2FaValidator,
} = require('../middlewares/userMiddlewares');

/**
 * Description: login  user
 * path: /login
 * Method: post
 * Body: { email: string,password: string, userToken?: string }
 */
router.post('/login', loginValidator, userController.login);

router.post('/admin/login', loginValidator, userController.loginAdmin);

/**
 * Description: get my profile
 * path: /me
 * Method: GET
 * Header: { Authorization: Bearer <accessToken> }
 */
router.get('/me', accessTokenValidator, userController.getMe);

/**
 * Description: register a new user
 * path: /register
 * Method: post
 * Body: {username: string, email: string,password: string, confirm_password:string }
 */
router.post('/register', registerValidator, userController.register);

/**
 * Description: logout a new user
 * path: /logout
 * Method: post
 * Header: { Authorization: Bearer <accessToken> }
 * Body: { refresh_token: string }
 */
router.post(
    '/logout',
    accessTokenValidator,
    refreshTokenValidator,
    userController.logout
);

/**
 * Description: insert user
 * path: /insert
 * Method: post
 * Header: { Authorization: Bearer <accessToken> }
 * Body: { userPayload  }
 */

router.post(
    '/insert',
    accessTokenAdminValidator,
    insertUserValidator,
    userController.insertUser
);

/**
 * Description: update user
 * path: /insert
 * Method: post
 * Header: { Authorization: Bearer <accessToken> }
 * Body: { userPayload }
 */
router.patch(
    '/update/:id',
    accessTokenAdminValidator,
    updateUserValidator,
    userController.updateUser
);

router.delete('/:id', accessTokenAdminValidator, userController.deleteUser);

router.delete('/', accessTokenAdminValidator, userController.deleteManyUsers);

router.get('/', accessTokenAdminValidator, userController.getAllUsers);

/**
 * Description: getPaging
 * path: /getPaging
 * Method: get
 * Header: { Authorization: Bearer <accessToken> }
 * Query: { userQuery  }
 */
router.get('/getPaging', accessTokenAdminValidator, userController.getPaging);

router.get('/:id', accessTokenAdminValidator, userController.getUserById);

/**
 * Description: submit email to reset password
 * path: /forgot-password
 * Method: post
 * Body: {email: string}
 */
router.post(
    '/forgot-password',
    forgotPasswordValidator,
    userController.forgotPassword
);

/**
 * Description: verify link in email to reset password
 * path: /verify-forgot-password
 * Method: post
 * Body: {forgot_password_token: string}
 */
router.post(
    '/verify-forgot-password',
    verifyForPasswordTokenValidator,
    userController.verifyForgotPassword
);

/**
 * Description: reset password
 * path: /reset-password
 * Method: post
 * Body: {password: string, confirmPassword:string, forgotPasswordToken: string}
 */
router.post(
    '/reset-password',
    resetPasswordValidator,
    userController.resetPassword
);

/**
 * Description: Change password
 * path: /change-password
 * Method: PATCH
 * Body: {oldPassword:string, password:string,confirmPassword:string}
 * Header: { Authorization: Bearer <accessToken> }
 */
router.put(
    '/change-password',
    accessTokenValidator,
    changePasswordValidator,
    userController.changePassword
);

/**
 * Description: OAuth with google
 * path: /oauth/google
 * Method: get
 * query: { code: string}
 */
router.get('/api/oauth/google', userController.oauth);

/**
 * Description:  bật tính năng 2fa , trả qrCodeDataUrl
 * path: /enable-2fa
 * Method: post
 * Header: { Authorization: Bearer <accessToken> }
 */
router.post('/enable-2fa', accessTokenValidator, userController.enable2FA);

/**
 * Description: người dùng quét mã qr và nhập userToken gồm 6 số để xác thực bật 2fa
 * path: /verify-2fa
 * Method: post
 * Header: { Authorization: Bearer <accessToken> }
 * body: {userToken: string}
 */
router.post(
    '/verify-2fa',
    accessTokenValidator,
    verify2FaValidator,
    userController.verify2Fa
);

/**
 * Description: người dùng  nhập userToken gồm 6 số để xác thực tắ 2fa
 * path: /verify-2fa
 * Method: post
 * Header: { Authorization: Bearer <accessToken> }
 * body: {userToken: string}
 */
router.post(
    '/disable-2fa',
    accessTokenValidator,
    verify2FaValidator,
    userController.disable2Fa
);

module.exports = router;
