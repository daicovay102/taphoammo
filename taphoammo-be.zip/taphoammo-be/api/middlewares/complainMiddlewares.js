const { validate, checkObjectIdOptions } = require('../../utilities/validation');
const { checkSchema } = require('express-validator');

const createValidator = validate(
    checkSchema(
        {
            orderId: {
                trim: true,
                custom: { options: checkObjectIdOptions('orderId') },
            },
            content: { isString: { options: { min: 10 } }, optional: false }
        },
        ['body']
    )
);

const getPagingValidator = validate(
    checkSchema(
        {
            pageSize: { isInt: { options: { min: 1 } } },
            pageIndex: { isInt: { options: { min: 1 } } },
            shopId: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('shopId') },
            },
            createdBy: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('createdBy') },
            },
            orderId: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('orderId') },
            },
        },
        ['query']
    )
);

const getByIdValidator = validate(
    checkSchema(
        {
            id: {
                trim: true,
                custom: { options: checkObjectIdOptions('id') },
            },
        },
        ['params']
    )
);

const updateValidator = validate(
    checkSchema(
        {
            id: {
                trim: true,
                optional: false,
                custom: { options: checkObjectIdOptions('id') },
            },
            content: { isString: { options: { min: 10 } }, optional: false }
        },
        ['body']
    )
);

module.exports = {
    createValidator,
    getPagingValidator,
    getByIdValidator,
    updateValidator
};