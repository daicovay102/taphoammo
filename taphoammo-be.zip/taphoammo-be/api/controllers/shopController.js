const Shops = require('../../database/entities/Shops');
const Products = require('../../database/entities/Products');
const PagedModel = require('../models/PagedModel');
const ResponseModel = require('../models/ResponseModel');
const shopService = require('../services/shopService');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const { USER_ROLE, ORDER_STATUS } = require('../../constants/enum');
const { Types } = require('mongoose');
const Orders = require('../../database/entities/Orders');

async function insert(req, res) {
    try {
        let count = await Shops.find({ 'createdBy': req.userId }).countDocuments();
        if (count >= 5) {
            return res.json(new ResponseModel(-1, 'Bạn được tạo tối đa 5 gian hàng!', null));
        }
        let check_name = await Shops.findOne({ '$and': [{ 'name': req.body.name }, { 'createdBy': req.userId }] });
        if (check_name) {
            return res.json(new ResponseModel(-1, 'Gian hàng này đã tồn tại!', null));
        }
        const data = await shopService.insert(req.body, req.userId);
        return res.json(
            new ResponseModel(1, 'Thêm gian hàng thành công.', data)
        );

    } catch (error) {
        const status = error.status || HTTP_STATUS.INTERNAL_SERVER_ERROR;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getPaging(req, res) {
    try {
        const data = await shopService.getPaging(req.query);
        return res.json(new PagedModel(data.pageIndex, data.pageSize, data.count, data.data));
    } catch (error) {
        const status = error.status || HTTP_STATUS.INTERNAL_SERVER_ERROR;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }

}

async function getAll(req, res) {
    const dataRes = await shopService.getAll({ deleted: false });
    return res.json(dataRes);
}

async function getById(req, res) {

    try {
        const dataRes = await shopService.getById(req.params.id);
        return res.json(dataRes);
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getBySlug(req, res) {

    if (req.params.slug) {
        try {
            let shop = await Shops.findOne({ slug: req.params.slug }).populate('business_typeId shop_typeId product_typeId');
            if (shop) {
                let list_product = await Products.find({ '$and': [{ 'shopId': shop._id }] });
                return res.json({ ...shop.toJSON(), products: list_product });
            } else {
                res.json(null);
            }

        } catch (error) {
            const status = error.status || HTTP_STATUS.INTERNAL_SERVER_ERROR;
            res.status(status).json(new ResponseModel(status, error.message, error));
        }
    } else {
        res.sendStatus(403);
    }
}

async function deleteById(req, res) {

    try {
        const shop = await shopService.getById(req.params.id);
        if (!shop) {
            return res.json(new ResponseModel(0, 'Không tìm thấy gian hàng.', null));
        }
        if (req.role !== USER_ROLE.Admin && req.userId !== shop.createdBy) {
            return res.json(new ResponseModel(0, 'Không có quyền xoá gian hàng.', null));
        }
        // xoa cua hang, xoa san pham, hoan tien order.
        const isHaveOrder = await Orders.findOne({ status: { $in: [ORDER_STATUS.DOI_CHAP_THUAN, ORDER_STATUS.KHIEU_NAI, ORDER_STATUS.TAM_GIU_TIEN, ORDER_STATUS.DANG_THUC_HIEN] } }, { _id: 1 });
        if (isHaveOrder) {
            return res.json(new ResponseModel(0, 'Không thể xoá gian hàng do đang có đơn hàng. Vui lòng xử lý đơn hàng trước', null));
        }
        const [deleteRes] = await Promise.all([
            Shops.findByIdAndUpdate(req.params.id, { deleted: true }),
            Products.updateMany({ shopId: shop._id }, { deleted: true })
        ]);
        return res.json(new ResponseModel(1, 'Xóa gian hàng thành công', deleteRes));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function update(req, res) {

    try {
        if (req.body.name) {
            let check_name = await shopService.checkNameShopUpdate(req.params.id, req.body.name);
            if (check_name) {
                return res.json(new ResponseModel(-1, 'Gian hàng này đã tồn tại!', null));
            }
        }
        const updated = await shopService.update(req.params.id, req.body, req.userId);
        if (!updated) {
            return res.json(new ResponseModel(0, 'Không tìm thấy gian hàng!', null));
        } else {
            return res.json(new ResponseModel(1, 'Cập nhập gian hàng thành công.', updated));
        }

    } catch (error) {
        const status = error.status || HTTP_STATUS.INTERNAL_SERVER_ERROR;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }

}

exports.insert = insert;
exports.getAll = getAll;
exports.getById = getById;
exports.getBySlug = getBySlug;
exports.deleteById = deleteById;
exports.update = update;
exports.getPaging = getPaging;