const { checkSchema } = require('express-validator');
const { validate, checkObjectIdOptions } = require('../../utilities/validation');
const { ORDER_STATUS } = require('../../constants/enum');

const createOrderValidator = validate(
    checkSchema(
        {
            productId: {
                trim: true,
                custom: { options: checkObjectIdOptions('productId') },
            },
            quantity: { isInt: { options: { min: 1 } }, optional: false },
            discountCode: { isString: true, optional: true },
            orderDuration: { isInt: { options: { min: 1, max: 7 } }, optional: true }
        },
        ['body']
    )
);


const getByIdValidator = validate(
    checkSchema(
        {
            id: {
                trim: true,
                custom: { options: checkObjectIdOptions('id') },
            },
        },
        ['params']
    )
);

const getPagingValidator = validate(
    checkSchema(
        {
            pageSize: { isInt: { options: { min: 1 } } },
            pageIndex: { isInt: { options: { min: 1 } } },
            productId: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('productId') },
            },
            shopId: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('shopId') },
            },
            buyerId: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('buyerId') },
            },
            sellerId: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('sellerId') },
            },
        },
        ['query']
    )
);

const updateValidator = validate(
    checkSchema(
        {
            id: {
                trim: true,
                optional: false,
                custom: { options: checkObjectIdOptions('id') },
            },
            quantity: { isInt: { options: { min: 1 } }, optional: true },
            status: {
                isIn: {
                    options: [Object.values(ORDER_STATUS)],
                    errorMessage: `Seller status wrong. Must be one of ${Object.values(ORDER_STATUS)}`
                },
                optional: true
            },
            orderDuration: { isInt: { options: { min: 1, max: 7 } }, optional: true }
        },
        ['body']
    )
);

module.exports = { createOrderValidator, getByIdValidator, getPagingValidator, updateValidator };