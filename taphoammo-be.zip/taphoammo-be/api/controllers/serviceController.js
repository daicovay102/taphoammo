const PagedModel = require('../models/PagedModel');
const ResponseModel = require('../models/ResponseModel');
const serviceService = require('../services/serviceService');
const shopService = require('../services/shopService');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const { mod } = require('qrcode/lib/core/polynomial');

async function insert(req, res) {
    try {
        let check_shop = await shopService.checkShopById(req.body.shopId);
        if (!check_shop) {
            return res.json(new ResponseModel(-1, 'Gian hàng của bạn không tồn tại!', null));
        }

        let check_name = await serviceService.checkNameServiceByShop(req.body.name, req.body.shopId);
        if (check_name) {
            return res.json(new ResponseModel(-1, 'Dịch vụ này đã tồn tại trong gian hàng!', null));
        }

        const data = await serviceService.insert(req.body, req.userId);
        return res.json(
            new ResponseModel(1, 'Thêm dịch vụ thành công.', data)
        );

    } catch (error) {
        const status = error.status || HTTP_STATUS.INTERNAL_SERVER_ERROR;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getAll(req, res) {
    try {
        const dataRes = await serviceService.getAll(req.userId);
        return res.json(dataRes);
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getById(req, res) {
    try {
        const dataRes = await serviceService.getById(req.params.id);
        return res.json(dataRes);
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getPaging(req, res) {
    try {
        const data = await serviceService.getPaging(req.query, req.userId);
        return res.json(new PagedModel(data.pageIndex, data.pageSize, data.count, data.data));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }

}

async function deleteById(req, res) {
    try {
        const product = await serviceService.getById(req.params.id);
        if (!product) {
            res.json(new ResponseModel(0, 'Không tìm thấy dịch vụ.', null));
        } else {
            let updated = await serviceService.deleteById(req.params.id, req.userId);
            if (!updated) {
                res.json(new ResponseModel(0, 'Không tìm thấy dịch vụ.', null));
            } else {
                res.json(new ResponseModel(1, 'Xóa dịch vụ thành công', updated));
            }
        }
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }

}

async function update(req, res) {
    try {
        if (req.body.name) {
            let check_name = await serviceService.checkNameServiceUpdate(req.params.id, req.body.name);
            if (check_name) {
                return res.json(new ResponseModel(-1, 'Dịch vụ này đã tồn tại trong gian hàng!', null));
            }
        }
        const updated = await serviceService.update(req.params.id, req.body, req.userId);
        if (!updated) {
            return res.json(new ResponseModel(0, 'Không tìm thấy dịch vụ!', null));
        } else {
            return res.json(new ResponseModel(1, 'Cập nhập dịch vụ thành công.', updated));
        }

    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        return res.status(status).json(new ResponseModel(status, error.message, error));
    }

}

module.exports = {
    insert,
    getAll,
    getById,
    deleteById,
    update,
    getPaging
};
