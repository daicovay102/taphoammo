require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const { Schema } = mongoose;

const complainSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    orderId: {
        type: Schema.Types.ObjectId,
        ref: 'Order',
        required: true
    },
    productId: {
        type: Schema.Types.ObjectId,
        ref: 'Products',
        required: true
    },
    content: {
        type: String, required: true, trim: true
    }
}, {
    versionKey: false,
    timestamps: true
});
complainSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Complains', complainSchema);
