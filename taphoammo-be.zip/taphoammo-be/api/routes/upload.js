const multer = require('multer');
const path = require('path');
const { randomString } = require('../../utilities/random');
const fs = require('fs');

const path_image = 'uploads/images';
const path_file = 'uploads/files';
const imageStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path_image);
    },
    filename: async function (req, file, cb) {
        const fileExtension = path.extname(file.originalname).toLowerCase();
        const fileName = randomString(16);

        cb(null, `${fileName}${fileExtension}`);
    },
});

const fileStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const { productId, shopId } = req.body;
        console.log(JSON.stringify(req.body));
        // tao thu muc
        if (!fs.existsSync(path.join(__dirname, '../..', path_file))) {
            fs.mkdirSync(path.join(__dirname, '../..', path_file));
        }
        let savePath = '';
        if (shopId && productId) {
            if (!fs.existsSync(path.join(__dirname, '../..', path_file, shopId))) {
                fs.mkdirSync(path.join(__dirname, '../..', path_file, shopId));
            }
            if (!fs.existsSync(path.join(__dirname, '../..', path_file, shopId, productId))) {
                fs.mkdirSync(path.join(__dirname, '../..', path_file, shopId, productId));
            }
            savePath = `${path_file}/${shopId}/${productId}`;
        } else {
            if (!fs.existsSync(path.join(__dirname, '../..', path_file, req.userId))) {
                fs.mkdirSync(path.join(__dirname, '../..', path_file, req.userId));
            }
            savePath = `${path_file}/${req.userId}`;
        }
        cb(null, savePath);
    },
    filename: async function (req, file, cb) {
        const fileExtension = path.extname(file.originalname).toLowerCase();
        const allowedExtensions = ['.zip'];
        let fileName = randomString(16);

        if (allowedExtensions.includes(fileExtension)) {
            cb(null, `${fileName}${fileExtension}`);
        } else {
            cb(
                new Error('Invalid File file type. Only zip files are allowed.')
            );
        }
    },
});


const fileUpload = multer({
    limits: {
        fileSize: 10 * 1024 * 1024, // 10 MB (in bytes)
    },
    storage: fileStorage,
});

const imageUpload = multer({
    limits: {
        fileSize: 5 * 1024 * 1024, // 100 MB (in bytes)
    },
    storage: imageStorage,
});

module.exports = {
    imageStorage,
    imageUpload,
    fileStorage,
    fileUpload
};
