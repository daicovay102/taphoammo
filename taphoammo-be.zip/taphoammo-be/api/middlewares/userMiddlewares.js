const { checkSchema } = require('express-validator');
const { JsonWebTokenError } = require('jsonwebtoken');
const { USER_ROLE } = require('../../constants/enum');
const { capitalize } = require('lodash');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const ReFreshTokens = require('../../database/entities/ReFreshTokens');
const Users = require('../../database/entities/Users');
const { hashPassword } = require('../../utilities/cryto');
const { verifyToken } = require('../../utilities/jwt');
const { validate } = require('../../utilities/validation');
const ErrorWithStatus = require('../models/Errors');
const { checkEmailExits } = require('../services/userService');
const { Types } = require('mongoose');
const { verify2FA } = require('../../utilities/authentication2FA');
require('dotenv').config();

const userNameSchema = {
    notEmpty: {
        errorMessage: 'Vui lòng nhập tài khoản!',
    },
    trim: true,
};

const emailSchema = {
    isEmail: {
        errorMessage: 'Email không hợp lệ!',
    },
    trim: true,
    custom: {
        options: async (value) => {
            const isExits = await checkEmailExits(value);
            if (isExits) {
                throw new Error('Email đã tồn tại!');
            }
            return true;
        },
    },
};

const passwordSchema = {
    notEmpty: {
        errorMessage: 'Vui lòng nhập mật khẩu!',
    },
    isLength: {
        options: {
            min: 6,
            max: 50,
        },
        errorMessage: 'Mật khẩu phải từ 6 đến 50 kí tự!',
    },
};

const forgotPasswordTokenSchema = {
    trim: true,
    custom: {
        options: async (value, { req }) => {
            if (!value) {
                throw new ErrorWithStatus({
                    message: 'Yêu cầu forgot password token.',
                    status: HTTP_STATUS.UNAUTHORIZED,
                });
            }
            try {
                const decodeForgotPasswordToken = await verifyToken({
                    token: value,
                    secretOrPublicKey: process.env.JWT_SECRECT_FORGOT_PASS_WORK_TOKEN,
                });
                const { userId } = decodeForgotPasswordToken;
                const user = await Users.findById(Types.ObjectId(userId));

                if (!user) {
                    throw new ErrorWithStatus({
                        message: 'Không tìm thấy tài khoản.',
                        status: HTTP_STATUS.UNAUTHORIZED,
                    });
                }
                if (user.forgotPasswordToken !== value) {
                    throw new ErrorWithStatus({
                        message: 'Forgot password token không hợp lệ.',
                        status: HTTP_STATUS.UNAUTHORIZED,
                    });
                }
                req.decodeForgotPasswordToken = decodeForgotPasswordToken;
            } catch (error) {
                if (error instanceof JsonWebTokenError) {
                    throw new ErrorWithStatus({
                        message: capitalize(error.message),
                        status: HTTP_STATUS.UNAUTHORIZED,
                    });
                }
                throw error;
            }
        },
    },
};

const passwordConfirmSchema = {
    notEmpty: {
        errorMessage: 'Vui lòng nhập xác nhận mật khẩu!',
    },
    custom: {
        options: (value, { req }) => {
            if (value !== req.body.password) {
                throw new Error('Xác nhận mật khẩu phải giống mật khẩu!');
            }

            return true;
        },
    },
};

const registerValidator = validate(
    checkSchema(
        {
            userName: userNameSchema,
            email: emailSchema,
            password: passwordSchema,
            confirmPassword: passwordConfirmSchema,
        },
        ['body']
    )
);

const loginValidator = validate(
    checkSchema(
        {
            email: {
                isEmail: {
                    errorMessage: 'Email không hợp lệ!',
                },
                trim: true,
                custom: {
                    options: async (value, { req }) => {
                        const user = await Users.findOne({
                            email: value,
                            password: hashPassword(req.body.password),
                        });
                        if (!user) {
                            throw new Error('Email hoặc mật khẩu không đúng!');
                        }
                        req.user = user;
                        return true;
                    },
                },
            },
        },
        ['body']
    )
);

const accessTokenValidator = validate(
    checkSchema(
        {
            Authorization: {
                trim: true,
                custom: {
                    options: async (value, { req }) => {
                        const accessToken = (value || '').split(' ')[1];
                        if (!accessToken) {
                            throw new ErrorWithStatus({
                                message: 'Vui lòng đăng nhập để tiếp tục trải nghiệm!',
                                status: HTTP_STATUS.UNAUTHORIZED,
                            });
                        }
                        try {
                            const decodedAuthorization = await verifyToken({
                                token: accessToken,
                                secretOrPublicKey: process.env.JWT_SECRET_ACCESS_TOKEN,
                            });
                            req.userId = decodedAuthorization.user._id;
                        } catch (error) {
                            if (error instanceof JsonWebTokenError) {
                                throw new ErrorWithStatus({
                                    message: capitalize(error.message),
                                    status: HTTP_STATUS.UNAUTHORIZED,
                                });
                            }
                            throw error;
                        }
                        return true;
                    },
                },
            },
        },
        ['headers']
    )
);

const accessTokenAdminValidator = validate(
    checkSchema(
        {
            Authorization: {
                trim: true,
                custom: {
                    options: async (value, { req }) => {
                        const accessToken = (value || '').split(' ')[1];
                        if (!accessToken) {
                            throw new ErrorWithStatus({
                                message: 'Yêu cầu accessToken!',
                                status: HTTP_STATUS.UNAUTHORIZED,
                            });
                        }
                        try {
                            const authorizedData = await verifyToken({
                                token: accessToken,
                                secretOrPublicKey: process.env.JWT_SECRET_ACCESS_TOKEN,
                            });
                            const { role, _id } = authorizedData.user;
                            //check auth admin
                            if (role !== USER_ROLE.Admin) {
                                throw new ErrorWithStatus({
                                    message:
                                        'Xin lỗi, bạn không có quyền truy cập chức năng này.',
                                    status: HTTP_STATUS.UNAUTHORIZED,
                                });
                            }
                            req.userId = _id;
                        } catch (error) {
                            if (error instanceof JsonWebTokenError) {
                                throw new ErrorWithStatus({
                                    message: capitalize(error.message),
                                    status: HTTP_STATUS.UNAUTHORIZED,
                                });
                            }
                            throw error;
                        }
                        return true;
                    },
                },
            },
        },
        ['headers']
    )
);

const refreshTokenValidator = validate(
    checkSchema(
        {
            refreshToken: {
                trim: true,
                custom: {
                    options: async (value, { req }) => {
                        if (!value) {
                            throw new ErrorWithStatus({
                                message: 'Yêu cầu refresh token.',
                                status: HTTP_STATUS.UNAUTHORIZED,
                            });
                        }
                        try {
                            const [decodeRefreshToken, refreshToken] = await Promise.all([
                                verifyToken({
                                    token: value,
                                    secretOrPublicKey: process.env.JWT_SECRECT_REFRSH_TOKEN,
                                }),
                                ReFreshTokens.findOne({ token: value }),
                            ]);
                            if (!refreshToken) {
                                throw new ErrorWithStatus({
                                    message: 'Refresh Token không tồnt tại',
                                    status: HTTP_STATUS.UNAUTHORIZED,
                                });
                            }
                            req.decodedRefreshToken = decodeRefreshToken;
                        } catch (error) {
                            if (error instanceof JsonWebTokenError) {
                                throw new ErrorWithStatus({
                                    message: capitalize(error.message),
                                    status: HTTP_STATUS.UNAUTHORIZED,
                                });
                            }
                            throw error;
                        }
                    },
                },
            },
        },
        ['body']
    )
);

const insertUserValidator = validate(
    checkSchema(
        {
            userName: userNameSchema,
            email: emailSchema,
            password: passwordSchema,
            fullName: {
                optional: true,
                trim: true,
                isString: {
                    errorMessage: 'Vui lòng nhập họ và tên là văn bản.',
                },
            },
            phoneNumber: {
                optional: true,
                trim: true,
                isString: {
                    errorMessage: 'Vui lòng nhập số điện thoại là văn bản.',
                },
            },
            role: {
                notEmpty: {
                    errorMessage: 'Vui lòng chọn vai trò.',
                },
            },
        },
        ['body']
    )
);

const updateUserValidator = validate(
    checkSchema(
        {
            email: {
                optional: true,
                ...emailSchema,
            },
        },
        ['body']
    )
);

const forgotPasswordValidator = validate(
    checkSchema(
        {
            email: {
                isEmail: {
                    errorMessage: 'Vui lòng nhập email!',
                },
                trim: true,
                custom: {
                    options: async (value, { req }) => {
                        const user = await Users.findOne({
                            email: value,
                        });
                        if (!user) {
                            throw new ErrorWithStatus({
                                message: 'Email không tồn tại!',
                                status: HTTP_STATUS.NOT_FOUND,
                            });
                        }
                        req.user = user;
                        return true;
                    },
                },
            },
        },
        ['body']
    )
);

const verifyForPasswordTokenValidator = validate(
    checkSchema(
        {
            forgotPasswordToken: forgotPasswordTokenSchema,
        },
        ['body']
    )
);

const resetPasswordValidator = validate(
    checkSchema(
        {
            password: passwordSchema,
            confirmPassword: passwordConfirmSchema,
            forgotPasswordToken: forgotPasswordTokenSchema,
        },
        ['body']
    )
);

const changePasswordValidator = validate(
    checkSchema(
        {
            oldPassword: {
                ...passwordSchema,
                custom: {
                    options: async (value, { req }) => {
                        const { userId } = req;
                        const user = await Users.findById(mongoose.Types.ObjectId(userId));
                        if (!user) {
                            throw new ErrorWithStatus({
                                message: 'Không tìm thấy tài khoản người dùng',
                                status: HTTP_STATUS.NOT_FOUND,
                            });
                        }
                        const { password } = user;
                        const isMatch = hashPassword(value) === password;
                        if (!isMatch) {
                            throw new ErrorWithStatus({
                                message: 'Mật khẩu cũ không đúng.',
                                status: HTTP_STATUS.UNAUTHORIZED,
                            });
                        }
                    },
                },
            },
            password: passwordSchema,
            confirmPassword: passwordConfirmSchema,
        },
        ['body']
    )
);

const verify2FaValidator = validate(
    checkSchema(
        {
            userToken: {
                trim: true,
                notEmpty: {
                    errorMessage: 'Yêu cầu nhập mã đăng nhập.',
                },
                custom: {
                    options: async (value, { req }) => {
                        const { userId } = req;
                        const user = await Users.findById(userId).select('google_2fa');
                        if (!user) {
                            throw new ErrorWithStatus({
                                message: 'Không tìm thấy tài khoản người dùng',
                                status: HTTP_STATUS.NOT_FOUND,
                            });
                        }
                        const { secret } = user.google_2fa;
                        const isVerified = verify2FA(secret, value);
                        if (!isVerified) {
                            throw new ErrorWithStatus({
                                message: 'Mã đăng nhập không hợp lệ.',
                                status: HTTP_STATUS.UNAUTHORIZED,
                            });
                        }
                        return true;
                    },
                },
            },
        },
        ['body']
    )
);

module.exports = {
    registerValidator,
    loginValidator,
    accessTokenValidator,
    accessTokenAdminValidator,
    refreshTokenValidator,
    insertUserValidator,
    updateUserValidator,
    forgotPasswordValidator,
    verifyForPasswordTokenValidator,
    resetPasswordValidator,
    changePasswordValidator,
    verify2FaValidator
};