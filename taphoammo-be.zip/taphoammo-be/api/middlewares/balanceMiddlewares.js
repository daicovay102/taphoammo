const { validate, checkObjectIdOptions } = require('../../utilities/validation');
const { checkSchema } = require('express-validator');
const { TRANSACTION_TYPE, ORDER_STATUS, TRANSACTION_STATUS } = require('../../constants/enum');

const editBalance = validate(
    checkSchema(
        {
            userId: {
                trim: true,
                custom: { options: checkObjectIdOptions('userId') },
                optional: false
            },
            amount: { isNumeric: true, optional: false }
        },
        ['body']
    )
);

const confirmDepositWithCode = validate(
    checkSchema(
        {
            code: {
                trim: true,
                isString: true,
                optional: false
            },
        },
        ['body']
    )
);
const createDepositCode = validate(
    checkSchema(
        {
            amount: { isInt: { options: { min: 1 } }, optional: false }
        },
        ['body']
    )
);

const getPaging = validate(
    checkSchema(
        {
            userId: {
                trim: true,
                custom: { options: checkObjectIdOptions('userId') },
                optional: true
            },
            status: {
                isIn: {
                    options: [Object.values(TRANSACTION_STATUS)]
                },
                optional: true
            },
        },
        ['query']
    )
);

const userWithdraw = validate(
    checkSchema(
        {
            amount: { isInt: { options: { min: 1 } }, optional: false }
        },
        ['body']
    )
);
const changeTractionStatus = validate(
    checkSchema(
        {
            id: {
                trim: true,
                custom: { options: checkObjectIdOptions('id') },
                optional: false
            },
            status: {
                isIn: {
                    options: [Object.values(TRANSACTION_STATUS)]
                },
                optional: false
            },
        },
        ['body']
    )
);

module.exports = {
    editBalance,
    confirmDepositWithCode,
    createDepositCode,
    getPaging,
    userWithdraw,
    changeTractionStatus
};