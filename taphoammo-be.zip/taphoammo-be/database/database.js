const mongoose = require('mongoose');

class Database {
    constructor() {
        this._connect();
    }

    _connect() {
        const mongodbURL = 'mongodb+srv://taphoammo:UEZMcxhZy4MxbSZi@cluster0.q1wyt9k.mongodb.net';
        mongoose.set('strictQuery', false);
        mongoose
            .connect(mongodbURL)
            .then(() => {
                console.log('Database connection successful');
            })
            .catch((err) => {
                console.error('Database connection error');
            });
    }
}

module.exports = new Database();
