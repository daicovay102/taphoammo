const nodemailer = require("nodemailer");
require("dotenv").config();

async function sendResetEmail(email, resetLink) {
  try {
    const transporter = nodemailer.createTransport({
      service: "Gmail",
      auth: {
        user: process.env.GMAIL_AUTH_USER,
        pass: process.env.GMAIL_PASSWORD_PASSWORD,
      },
    });

    // Cấu hình thông điệp email
    const mailOptions = {
      from: process.env.GMAIL_AUTH_USER,
      to: email,
      subject: "Reset Your Password",
      html: `<p>Click the following link to reset your password: <a href="${resetLink}">${resetLink}</a></p>`,
    };

    // Gửi email
    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent: ", info.response);
  } catch (error) {
    console.error("Error sending email: ", error);
    throw error;
  }
}

module.exports = sendResetEmail;
