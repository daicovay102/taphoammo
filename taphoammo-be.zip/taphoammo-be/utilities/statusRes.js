const ResponseModel = require("../api/models/ResponseModel");
const { HTTP_STATUS } = require("../constants/httpStatus");

exports.responseError = (res, error) => {
  const status = error.status || HTTP_STATUS.INTERNAL_SERVER_ERROR;
  res.status(status).json(new ResponseModel(status, error.message, error));
};

exports.responseSuccess = (res, message, data) => {
  res.status(200).json(new ResponseModel(1, message, data));
};
