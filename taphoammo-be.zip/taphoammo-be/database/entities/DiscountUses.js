require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const { Schema } = mongoose;

let discountUsesSchema = new Schema({
    discountId: {
        type: Schema.Types.ObjectId,
        ref: 'Discounts',
        required: true
    },
    buyerId: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },

}, {
    versionKey: false,
    timestamps: true
});

discountUsesSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('DiscountUses', discountUsesSchema);
