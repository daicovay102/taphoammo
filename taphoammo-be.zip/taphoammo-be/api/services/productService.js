const Products = require('../../database/entities/Products');
const { isValidObjectId, Types } = require('mongoose');

exports.insert = async (payload, userId) => {
    const dataProduct = { ...payload, createdBy: userId };
    const newProduct = new Products(dataProduct);
    return await newProduct.save();
};
exports.getAll = async (filter) => {
    return Products.find(filter ? filter : {}).sort({ createdAt: 'desc', });
};

exports.getById = async (id) => {
    return await Products.findOneWithDeleted({ _id: isValidObjectId(id) ? id : null });
};

exports.checkNameProductByShop = async (name, shopId) => {
    return Products.findOne({ '$and': [{ 'name': name }] });
};

exports.checkNameProductUpdate = async (id, name) => {
    return Products.findOne({ '$and': [{ '_id': { '$ne': new Types.ObjectId(id) } }, { 'name': name }] });
};

exports.deleteById = async (id, userId) => {
    return Products.deleteOne({ '$and': [{ _id: id }, { createdBy: userId }] });
};
exports.update = async (id, payload, userId) => {
    return Products.findOneAndUpdate(
        { '$and': [{ _id: id }, { createdBy: userId }] },
        { updatedAt: Date.now(), ...payload },
        { new: true }
    );
};

exports.getPaging = async (query) => {
    let pageSize = query.pageSize || 10;
    let pageIndex = query.pageIndex || 1;

    const search = [];
    if (query.name) {
        search.push({
            $or: [
                { name: { $regex: new RegExp(query.name, 'i') } },
                { slug: { $regex: new RegExp(query.name, 'i') } }
            ]
        });
    }
    if (query.shopId) {
        search.push({ shopId: isValidObjectId(query.shopId) ? query.shopId : null });
    }
    if (query.productTypeId) {
        search.push({ productTypeId: isValidObjectId(query.productTypeId) ? query.productTypeId : null });
    }
    if (query.shopTypeId) {
        search.push({ shopTypeId: isValidObjectId(query.shopTypeId) ? query.shopTypeId : null });
    }
    if (query.businessTypeId) {
        search.push({ businessTypeId: isValidObjectId(query.businessTypeId) ? query.businessTypeId : null });
    }
    let data = await Products.find({ $and: search })
        .skip(pageSize * pageIndex - pageSize)
        .limit(parseInt(pageSize))
        .sort({
            createdAt: 'desc',
        });
    let count = await Products.find({ $and: search }).countDocuments();

    return { pageIndex, pageSize, count, data };
};

exports.getDetailById = async (id) => {
    const data = await Products.aggregate([
        { $match: { _id: new Types.ObjectId(id), deleted: false } },
        {
            $lookup: {
                from: 'shops',
                localField: 'shopId',
                foreignField: '_id',
                as: 'shop'
            }
        },
        {
            $unwind: {
                path: '$shop', preserveNullAndEmptyArrays: true
            }
        },
        {
            $lookup: {
                from: 'product_uploads',
                localField: '_id',
                foreignField: 'productId',
                as: 'images'
            }
        },
    ]);
    return data.length ? data[0] : null;
};