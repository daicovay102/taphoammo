const Orders = require('../../database/entities/Orders');
const { isValidObjectId } = require('mongoose');
const { BUYER_STATUS, SELLER_STATUS } = require('../../constants/enum');
const Services = require('../../database/entities/Services');
const { isNotNullAndUndefined } = require('../../utilities/validation');

const create = (body, product) => {
    return Orders.create(body);
};

const getById = async (id) => {
    return await Orders.findOneWithDeleted({ _id: isValidObjectId(id) ? id : null });
};

const getOne = async (filter) => {
    return Orders.findOne(filter);
};

const getAll = async () => {
    return Orders.find().sort({ createdAt: 'desc' });
};

const getPaging = async (query) => {
    const pageSize = Number.parseInt(query.pageSize) || 10;
    const pageIndex = Number.parseInt(query.pageIndex) || 1;

    const searchObj = {};

    const { buyerId, sellerId, shopId, productId, name, productTypeId, businessTypeId, shopTypeId, status } = query;
    if (shopId) {
        searchObj.shopId = isValidObjectId(shopId) ? shopId : null;
    }
    if (buyerId) {
        searchObj.buyerId = isValidObjectId(buyerId) ? buyerId : null;
    }
    if (sellerId) {
        searchObj.sellerId = isValidObjectId(sellerId) ? sellerId : null;
    }
    if (productId) {
        searchObj.productId = isValidObjectId(productId) ? productId : null;
    }
    if (productTypeId) {
        searchObj.productTypeId = isValidObjectId(productTypeId) ? productTypeId : null;
    }
    if (businessTypeId) {
        searchObj.businessTypeId = isValidObjectId(businessTypeId) ? businessTypeId : null;
    }
    if (shopTypeId) {
        searchObj.shopTypeId = isValidObjectId(shopTypeId) ? shopTypeId : null;
    }
    if (isNotNullAndUndefined(status)) {
        searchObj.status = status;
    }
    if (name) {
        searchObj.name = { $regex: new RegExp(name, 'i') };
    }
    const [data, count] = await Promise.all([
        Orders.aggregate([
            { $match: searchObj },
            { $sort: { createdAt: -1 } },
            { $skip: pageSize * pageIndex - pageSize },
            { $limit: pageSize },
            {
                $lookup: {
                    from: 'users',
                    localField: 'buyerId',
                    foreignField: '_id',
                    as: 'buyerId',
                    pipeline: [{ $project: { password: 0, balance: 0, forgotPasswordToken: 0 } }]
                },
            },
            { $unwind: { path: '$buyerId', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'users',
                    localField: 'sellerId',
                    foreignField: '_id',
                    as: 'sellerId',
                    pipeline: [{ $project: { password: 0, balance: 0, forgotPasswordToken: 0 } }]
                },
            },
            { $unwind: { path: '$sellerId', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'shops',
                    localField: 'shopId',
                    foreignField: '_id',
                    as: 'shopId'
                },
            },
            { $unwind: { path: '$shopId', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'products',
                    localField: 'productId',
                    foreignField: '_id',
                    as: 'productId'
                },
            },
            { $unwind: { path: '$productId', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'product_types',
                    localField: 'productTypeId',
                    foreignField: '_id',
                    as: 'productTypeId'
                },
            },
            { $unwind: { path: '$productTypeId', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'shop_types',
                    localField: 'shopTypeId',
                    foreignField: '_id',
                    as: 'shopTypeId'
                },
            },
            { $unwind: { path: '$shopTypeId', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'business_types',
                    localField: 'businessTypeId',
                    foreignField: '_id',
                    as: 'businessTypeId'
                },
            },
            { $unwind: { path: '$businessTypeId', preserveNullAndEmptyArrays: true } },
        ]),
        Orders.countDocuments(searchObj)
    ]);
    return { pageIndex, pageSize, count, data };
};

const update = async (id, body) => {
    const { statusSeller, quantity, price, discount, totalPayment, statusBuyer, orderDuration } = body;
    return Orders.findByIdAndUpdate(id, {
        statusSeller,
        quantity,
        price,
        discount,
        totalPayment,
        statusBuyer,
        orderDuration
    }, { new: true });
};

const deleteById = async (id, userId) => {
    return Orders.deleteOne({ '$and': [{ _id: id }, { createdBy: userId }] });
};

module.exports = {
    create,
    getById,
    getAll,
    getPaging,
    update,
    deleteById,
    getOne
};