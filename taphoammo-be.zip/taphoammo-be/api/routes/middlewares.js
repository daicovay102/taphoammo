const jwt = require('jsonwebtoken');
const ResponseModel = require('../models/ResponseModel');
const { USER_ROLE } = require('../../constants/enum');
require('dotenv').config();
const secretKey = process.env.JWT_SECRET_ACCESS_TOKEN;

async function authorize(req, res, next) {
    try {
        const bearerHeader = req.headers['authorization'];
        if (typeof bearerHeader !== 'undefined') {
            const token = bearerHeader.split(' ')[1];
            const authorizedData = await jwt.verify(token, secretKey);
            req.userId = authorizedData.user._id;
            req.role = authorizedData.user.role;
            next();
        } else {
            res.sendStatus(403);
        }
    } catch (error) {
        const response = new ResponseModel(403, error.message, error);
        res.status(403).json(response);
    }
}

async function authorizeAdmin(req, res, next) {
    try {
        const bearerHeader = req.headers['authorization'];

        if (typeof bearerHeader === 'undefined') {
            return res.sendStatus(403);
        }
        const token = bearerHeader.split(' ')[1];
        const authorizedData = await jwt.verify(token, secretKey);
        const { role, _id } = authorizedData.user;
        //check auth admin
        if (role !== USER_ROLE.Admin) {
            throw new Error('Xin lỗi, bạn không có quyền truy cập chức năng này.');
        }
        req.userId = _id;
        req.role = authorizedData.user.role;
        next();
    } catch (error) {
        const response = new ResponseModel(403, error.message, error);
        res.status(403).json(response);
    }
}

exports.authorize = authorize;
exports.authorizeAdmin = authorizeAdmin;
