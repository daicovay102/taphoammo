const { isValidObjectId, Types } = require('mongoose');
const ProductTypes = require('../../database/entities/ProductTypes');
const PagedModel = require('../models/PagedModel');
const ResponseModel = require('../models/ResponseModel');
require('dotenv').config();


async function insert(req, res) {
    try {
        let category = new ProductTypes(req.body);
        category.createdBy = req.userId;
        await category.save(function (err, newCategory) {
            if (err) {
                let response = new ResponseModel(-1, err.message, err);
                res.json(response);
            } else {
                let response = new ResponseModel(1, 'Create success!', newCategory);
                res.json(response);
            }
        });
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }

}


async function getPaging(req, res) {
    try {
        let pageSize = req.query.pageSize || 10;
        let pageIndex = req.query.pageIndex || 1;

        let searchObj = {};
        if (req.query.name) {
            searchObj = { name: { $regex: '.*' + req.query.name + '.*' } };
        }
        let data = await ProductTypes.find(searchObj)
            .skip(pageSize * pageIndex - pageSize)
            .limit(parseInt(pageSize))
            .sort({
                createdAt: 'desc',
            });
        const count = await ProductTypes.find(searchObj).countDocuments();
        let pagedModel = new PagedModel(pageIndex, pageSize, count, data);
        res.json(pagedModel);
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }

}

async function getAll(req, res) {
    const { shopTypeId } = req.query;
    const data = await ProductTypes.find(shopTypeId ? { shop_typeId: shopTypeId } : { shopTypeId });
    res.json(data);
}

async function getById(req, res) {

    if (req.params.id) {
        try {
            let product = await ProductTypes.findOneWithDeleted({ _id: req.params.id });
            res.json(product);
        } catch (error) {
            let response = new ResponseModel(-2, error.message, error);
            res.json(response);
        }
    } else {
        res.sendStatus(403);
    }

}

async function deleteById(req, res) {

    if (isValidObjectId(req.params.id)) {
        try {
            let category = await ProductTypes.findById(req.params.id);
            if (!category) {
                let response = new ResponseModel(0, 'No item found!', null);
                res.json(response);
            } else {

                let updated = await ProductTypes.delete({ _id: req.params.id });
                if (!updated) {
                    let response = new ResponseModel(0, 'No item found!', null);
                    res.json(response);
                } else {
                    let response = new ResponseModel(1, 'Delete success!', updated);
                    res.json(response);
                }
            }
        } catch (error) {
            let response = new ResponseModel(404, error.message, error);
            res.status(404).json(response);
        }
    } else {
        res.status(404).json(new ResponseModel(404, 'Id is not valid!', null));
    }


}

async function deleteMany(req, res) {

    try {
        const deleteResults = [];
        const categoryIds = req.body.ids;
        if (!categoryIds || !Array.isArray(categoryIds) || categoryIds.length === 0) {
            res.status(400).json(new ResponseModel(400, 'Invalid request body. \'ids\' array is required.', null));
            return;
        }

        if (!categoryIds.every(isValidObjectId)) {
            res.status(400).json(new ResponseModel(400, 'One or more categoryIds are not valid!', null));
            return;
        }

        const updateResult = await ProductTypes.delete({ _id: { $in: categoryIds } });

        if (updateResult.modifiedCount === 0) {
            res.json(new ResponseModel(200, 'No ProductTypes found for deletion!', deleteResults));
        } else {
            res.json(new ResponseModel(200, 'ProductTypes deletion results:', updateResult));
        }
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }

}

async function update(req, res) {

    try {
        let category = { updatedAt: Date.now(), ...req.body };
        let updated = await ProductTypes.findOneAndUpdate(
            { _id: req.params.id },
            category
        );
        if (!updated) {
            let response = new ResponseModel(0, 'No item found!', null);
            res.json(response);
        } else {
            let response = new ResponseModel(1, 'Updat success!', updated);
            res.json(response);
        }

    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }

}

module.exports = {
    insert,
    getAll,
    getById,
    deleteById,
    deleteMany,
    update,
    getPaging
};
