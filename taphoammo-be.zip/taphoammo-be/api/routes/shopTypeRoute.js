const express = require('express');
const router = express.Router();
const shopTypeController = require('../controllers/shopTypeController');
const middlewares = require('./middlewares');

router.post('/insert', middlewares.authorizeAdmin, shopTypeController.insert);
router.put('/update/:id', middlewares.authorizeAdmin, shopTypeController.update);
router.delete('/delete/:id', middlewares.authorizeAdmin, shopTypeController.deleteById);
router.delete('/deleteMany', middlewares.authorizeAdmin, shopTypeController.deleteMany);
router.get('/getAll', shopTypeController.getAll);
router.get('/getById/:id', shopTypeController.getById);
router.get('/getPaging', shopTypeController.getPaging);

module.exports = router;