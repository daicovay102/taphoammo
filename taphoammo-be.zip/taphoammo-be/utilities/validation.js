const { validationResult } = require('express-validator');
const ErrorWithStatus = require('../api/models/Errors');
const ResponseModel = require('../api/models/ResponseModel');
const { HTTP_STATUS } = require('../constants/httpStatus');
const { isValidObjectId } = require('mongoose');

const validate = (validations) => {
    return async (req, res, next) => {
        await validations.run(req);
        const errors = validationResult(req);

        if (errors.isEmpty()) {
            return next();
        }
        const errArray = errors.array();
        const response = new ResponseModel();
        response.data = errArray;
        for (const err of errArray) {
            const { msg } = err;
            // Trả về lỗi khác không phải là lỗi do validate
            if (msg instanceof ErrorWithStatus) {
                response.status = msg.status;
                response.message = msg.message;
                return res.status(msg.status).json(response);
            }
        }
        // trả lỗi do validate
        response.message = errors.array()[0].msg;
        response.status = HTTP_STATUS.BAD_REQUEST;
        return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
    };
};

const checkObjectIdOptions = (fieldName) => {
    return (value, { req }) => {
        if (!value) {
            throw new ErrorWithStatus({
                message: `${fieldName} required`,
                status: HTTP_STATUS.BAD_REQUEST,
            });
        }
        if (!isValidObjectId(value)) {
            throw new ErrorWithStatus({
                message: `${fieldName} wrong`,
                status: HTTP_STATUS.BAD_REQUEST,
            });
        }
        return true;
    };
};

const isNotNullAndUndefined = (value) => value !== null && value !== undefined;

module.exports = { validate, checkObjectIdOptions, isNotNullAndUndefined };