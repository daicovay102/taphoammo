const ShopEvaluations = require('../../database/entities/ShopEvaluations');
const { isValidObjectId } = require('mongoose');

const insert = async (body, userId) => {
    const { content, reviewPoint, shopId } = body;
    return await ShopEvaluations.create({ createdBy: userId, shopId, content, reviewPoint });
};

const getById = async (id) => {
    return await ShopEvaluations.findOneWithDeleted({ _id: isValidObjectId(id) ? id : null });
};
const getAll = async () => {
    return ShopEvaluations.find().sort({ createdAt: 'desc' });
};

const getPaging = async (query,) => {
    const pageSize = Number.parseInt(query.pageSize) || 10;
    const pageIndex = Number.parseInt(query.pageIndex) || 1;
    const searchObj = {};

    if (query.shopId) {
        searchObj.shopId = isValidObjectId(query.shopId) ? query.shopId : null;
    }
    if (query.createdBy) {
        searchObj.createdBy = isValidObjectId(query.createdBy) ? query.createdBy : null;
    }
    const [data, count] = await Promise.all([
        ShopEvaluations.find(searchObj)
            .skip(pageSize * pageIndex - pageSize)
            .limit(pageSize)
            .sort({ createdAt: 'desc' }),
        ShopEvaluations.countDocuments(searchObj)
    ]);
    return { pageIndex, pageSize, count, data };
};

const update = async (id, body) => {
    const { content, reviewPoint } = body;
    return ShopEvaluations.findByIdAndUpdate(id, {
        content,
        reviewPoint,
    }, { new: true });
};

const deleteById = async (id, userId) => {
    return ShopEvaluations.delete({ '$and': [{ _id: id }, { createdBy: userId }] });
};

const getOne = async (filter) => {
    return ShopEvaluations.findOne(filter);
};

module.exports = { insert, getById, getAll, getPaging, update, deleteById, getOne };