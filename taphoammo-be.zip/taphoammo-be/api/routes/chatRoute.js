const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');
const middlewares = require('./middlewares');
const {
    createValidator,
    messageValidator
} = require('../middlewares/chatMiddlewares');

router.post('/insert', createValidator, middlewares.authorize, chatController.insert);

router.post('/message', messageValidator, middlewares.authorize, chatController.message);

router.get('/getAll', middlewares.authorize, chatController.getAll);

module.exports = router;