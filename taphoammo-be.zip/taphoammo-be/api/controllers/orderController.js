const orderService = require('../services/orderService');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const ResponseModel = require('../models/ResponseModel');
const PagedModel = require('../models/PagedModel');
const Discounts = require('../../database/entities/Discounts');
const Users = require('../../database/entities/Users');
const Transactions = require('../../database/entities/Transactions');
const ProductTypes = require('../../database/entities/ProductTypes');
const Orders = require('../../database/entities/Orders');
const Shops = require('../../database/entities/Shops');
const ProductImports = require('../../database/entities/ProductImports');
const Products = require('../../database/entities/Products');
const DiscountUses = require('../../database/entities/DiscountUses');
const AdmZip = require('adm-zip');
const { ORDER_STATUS, TRANSACTION_TYPE, DISCOUNT_TYPE, PRODUCT_IMPORT_STATUS } = require('../../constants/enum');
const moment = require('moment');
const { isNotNullAndUndefined } = require('../../utilities/validation');
const path = require('path');

const checkDiscount = async (discountCode, shop, userId) => {
    let message = null;
    const discount = await Discounts.findOne({ code: discountCode.toLowerCase() });
    if (!discount) {
        return { message: 'KHONG TIM THAY MA GIAM GIA' };
    }
    if (moment().isBefore(moment(discount.startDate)) || moment().isAfter(moment(discount.endDate))) {
        return { message: 'MA GIAM GIA HET HAN' };
    }
    if (isNotNullAndUndefined(discount.shopId) && discount.shopId.toString() !== shop._id.toString()) {
        return { message: 'MA GIAM GIA KHONG AP DUNG CHO CUA HANG NAY' };
    } else if (!isNotNullAndUndefined(discount.shopId) && shop.createdBy.toString() !== discount.createdBy.toString()) {
        return { message: 'MA GIAM GIA KHONG AP DUNG CHO CUA HANG NAY' };
    }
    if (discount.leftOfUses <= 0) {
        return { message: 'MA GIAM GIA HET LUOT SU DUNG' };
    }
    const hasUses = await DiscountUses.findOne({ discountId: discount._id, buyerId: userId });
    if (hasUses) {
        return { message: 'DA SU DUNG MA GIAM GIA NAY TRUOC DO' };
    }
    return { discount, message };
};


const calculateDiscount = async (discount, totalValue) => {
    let discountValue = 0;
    if (discount.type === DISCOUNT_TYPE.PHAN_TRAM) {
        const discountVal = (discount.percentage / 100) * totalValue;
        discountValue = discountVal > discount.maxPriceValue ? discount.maxPriceValue : discountVal;
    } else {
        discountValue = discount.value;
    }
    return discountValue;
};

const createOrder = async (req, res) => {
    try {
        const { productId, quantity, discountCode, orderDuration } = req.body;

        // kiem tra san pham
        const product = await Products.findOne({ _id: productId, deleted: false });
        if (!product) {
            const response = new ResponseModel(HTTP_STATUS.BAD_REQUEST, 'KHONG TIM THAY SAN PHAM', null);
            return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
        }
        if (product.quantity < quantity) {
            const response = new ResponseModel(HTTP_STATUS.BAD_REQUEST, 'KHONG DU SO LUONG SAN PHAM', null);
            return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
        }

        // kiem tra shop
        const shop = await Shops.findById(product.shopId);
        if (!shop) {
            const response = new ResponseModel(HTTP_STATUS.BAD_REQUEST, 'Shop not found', null);
            return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
        }

        // kiem tra nguoi ban
        const seller = await Users.findById(shop.createdBy, { _id: 1 });
        if (!seller) {
            const response = new ResponseModel(HTTP_STATUS.BAD_REQUEST, 'Không tìm thấy người bán', null);
            return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
        }

        // kiem tra nguoi mua
        const buyer = await Users.findById(req.userId, { _id: 1, balance: 1 });
        if (!buyer) {
            const response = new ResponseModel(HTTP_STATUS.BAD_REQUEST, 'Không tìm thấy người mua', null);
            return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
        }

        // kiem tra ma giam gia
        let discountValue = 0;
        let discount;
        if (discountCode) {
            const { message, discount: foundDiscount } = await checkDiscount(discountCode, shop, req.userId);
            if (message) {
                return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(HTTP_STATUS.BAD_REQUEST, message, null));
            }
            discount = foundDiscount;
            discountValue = await calculateDiscount(foundDiscount, product.price * quantity);
        }

        // kiem tra so du buyer
        const totalAmount = product.price * quantity;
        const amountAfterAppliedDiscount = totalAmount - discountValue;
        if (buyer.balance < amountAfterAppliedDiscount) {
            const response = new ResponseModel(HTTP_STATUS.BAD_REQUEST, 'Số dư tài khoản không đủ', null);
            return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
        }

        // chiet khau cho san
        const productType = await ProductTypes.findById(product.productTypeId);
        const amountFee = totalAmount * (productType.discount_percent / 100);

        const trackingAmount = {
            totalAmount,
            amountAfterAppliedDiscount,
            amountBuyerPay: amountAfterAppliedDiscount,
            amountForMerchant: amountAfterAppliedDiscount - amountFee > 0 ? amountAfterAppliedDiscount - amountFee : 0,
            amountFee
        };


        let order;
        let productImports = [];
        const session = await Orders.startSession();
        session.startTransaction();
        try {
            productImports = await ProductImports.find({
                productId: product._id,
                status: PRODUCT_IMPORT_STATUS.PENDING
            }, {}, {
                session,
                limit: quantity
            });
            if (productImports.length !== quantity) {
                return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(HTTP_STATUS.BAD_REQUEST, 'KHONG DU SO LUONG SAN PHAM', null));
            }
            const productImportIds = productImports.map(x => x._id);
            const newOrder = await Orders.create([{
                buyerId: req.userId,
                sellerId: seller._id,
                shopId: product.shopId,
                productId: product._id,
                productTypeId: product.productTypeId,
                businessTypeId: product.businessTypeId,
                shopTypeId: product.shopTypeId,
                name: product.name,
                price: product.price,
                quantity,
                discount: discountValue,
                totalPayment: amountAfterAppliedDiscount,
                status: ORDER_STATUS.TAM_GIU_TIEN,
                orderDuration,
                productImportIds,
                trackingAmount
            }], { session });
            await Users.findByIdAndUpdate(req.userId, { $inc: { balance: -amountAfterAppliedDiscount } }, { session });
            await Transactions.create([
                {
                    buyerId: req.userId,
                    sellerId: seller._id,
                    value: trackingAmount.amountForMerchant,
                    orderId: newOrder[0]._id,
                    type: TRANSACTION_TYPE.ORDER
                }
            ], { session });
            await Products.updateOne({ _id: product._id }, {
                $inc: {
                    quantity: -quantity,
                    soldQuantity: quantity
                }
            }, { session });
            await ProductImports.updateMany({ _id: { $in: productImportIds } }, {
                $set: {
                    sellerAt: new Date(),
                    sellerBy: seller._id,
                    status: PRODUCT_IMPORT_STATUS.SOLD
                }
            }, { session });
            if (discountCode) {
                await Discounts.updateOne({ code: discountCode.toLowerCase() }, { $inc: { leftOfUses: 1 } }, { session });
                await DiscountUses.create([{ discountId: discount._id, buyerId: req.userId }], { session });
            }
            await session.commitTransaction();
            order = newOrder[0];
        } catch (error) {
            await session.abortTransaction();
        } finally {
            await session.endSession();
        }
        if (order) {
            const zip = new AdmZip();
            try {
                productImports.map(x => {
                    zip.addLocalFolder(path.join(__dirname, '../../', x.filePath));
                });
            } catch (e) {
            }
            return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'Create order success', {
                order,
                products: zip.toBuffer()
            }));
        } else {
            res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, 'Create order failed', null));
        }
    } catch (e) {
        console.log(e);
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getAll = async (req, res) => {
    try {
        const orders = await orderService.getAll();
        return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'Get all order success', orders));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getPaging = async (req, res) => {
    try {
        const { pageIndex, pageSize, count, data } = await orderService.getPaging(req.query);
        return res.json(new PagedModel(pageIndex, pageSize, count, data));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getById = async (req, res) => {
    try {
        const result = await orderService.getById(req.params.id);
        return res.json(new ResponseModel(HTTP_STATUS.OK, 'Get order success', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const deleteById = async (req, res) => {
    try {
        const order = await orderService.getById(req.params.id);
        if (!order) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Order not found', null));
        } else {
            const result = await orderService.deleteById(req.params.id);
            res.json(new ResponseModel(1, 'Delete order success', result));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const update = async (req, res) => {
    try {
        const { id } = req.body;
        const order = await orderService.update(id, req.body);
        if (!order) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Order not found', null));
        } else {
            res.json(new ResponseModel(1, 'Update order success', order));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

module.exports = { getAll, getPaging, createOrder, getById, deleteById, update };