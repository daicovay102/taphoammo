const ProductImports = require('../../database/entities/ProductImports');
const Products = require('../../database/entities/Products');
const PagedModel = require('../models/PagedModel');
const ResponseModel = require('../models/ResponseModel');
const { isNotNullAndUndefined } = require('../../utilities/validation');
const { PRODUCT_IMPORT_STATUS } = require('../../constants/enum');
const fs = require('fs');
const path = require('path');

async function getPaging(req, res) {
    try {
        const { productId, pageSize, pageIndex } = req.query;
        const newPageSize = isNotNullAndUndefined(pageSize)
            ? Number.parseInt(pageSize)
            : 10;
        const newPageIndex = isNotNullAndUndefined(pageIndex)
            ? Number.parseInt(pageIndex)
            : 1;
        let searchObj = { ...(productId ? { productId } : {}) };
        let products = await ProductImports.find(searchObj)
            .skip(newPageSize * newPageIndex - newPageSize)
            .limit(newPageSize)
            .sort({
                createdAt: 'desc',
            });
        const count = await ProductImports.find(searchObj).countDocuments();
        let pagedModel = new PagedModel(newPageIndex, newPageSize, count, products);
        res.json(pagedModel);
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }

}

async function getAll(req, res) {
    const { productId } = req.query;
    const products = await ProductImports.find({ ...(productId ? { productId } : {}) }).sort({ createdAt: 'desc', });
    res.json(products);

}

async function deleteStatusActive(req, res) {
    try {
        const updateResult = await ProductImports.deleteOne({
            '$and': [
                { status: 1 },
                { createdBy: req.userId },
                { shopId: req.body.shopId }
            ]
        });
        if (updateResult.modifiedCount === 0) {
            return res.json(new ResponseModel(200, 'Không tìm thấy sản phẩm nào để xóa!', null));
        } else {
            return res.json(new ResponseModel(200, 'Kết quả xóa:', updateResult));
        }
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}


async function deleteProductImport(req, res) {
    try {
        const { productId } = req.query;
        const product = await Products.findById(productId);
        if (!product) {
            return res.json(new ResponseModel(200, 'KHONG TIM THAY SAN PHAM', null));
        }
        const productImports = await ProductImports.find({ productId, status: PRODUCT_IMPORT_STATUS.PENDING });
        if (productImports.length) {
            await Promise.all([
                ProductImports.deleteMany({ _id: { $in: productImports.map(x => x._id) } }),
                Products.findByIdAndUpdate(productId, { $inc: { quantity: -productImports.length } })
            ]);
            productImports.forEach(a => {
                try {
                    fs.unlinkSync(path.join(__dirname, '../../', a.filePath));
                } catch (e) {
                    console.log(e);
                }
            });
        }
        return res.json(new ResponseModel(200, 'XOA THANH CONG', productImports.length));
    } catch (error) {
        return res.status(404).json(new ResponseModel(404, error.message, error));
    }
}

module.exports = {
    getAll,
    getPaging,
    deleteStatusActive,
    deleteProductImport
};
