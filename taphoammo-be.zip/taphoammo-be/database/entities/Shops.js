require("../database");
const mongoose = require("mongoose");
const mongoose_delete = require("mongoose-delete");
const slug = require("mongoose-slug-generator");
const { SHOP_STATUS } = require("../../constants/enum");
mongoose.plugin(slug);
const { Schema } = mongoose;

let shopSchema = new Schema(
  {
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: "Users",
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    slug: {
      type: String,
      slug: "name",
      unique: true,
    },
    business_typeId: {
      type: Schema.Types.ObjectId,
      ref: "Business_types",
      required: true,
    },
    shop_typeId: {
      type: Schema.Types.ObjectId,
      ref: "Shop_types",
      required: true,
    },
    product_typeId: {
      type: Schema.Types.ObjectId,
      ref: "Product_types",
      required: true,
    },
    refund: {
      type: Number,
      default: 0,
    },
    isReseller: {
      type: Boolean,
      default: false,
    },
    isOwnWarehouse: {
      type: Boolean,
      default: false,
    },
    short_description: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    image: {
      type: String,
      required: true,
    },
    status: {
      type: Number,
      default: SHOP_STATUS.Pending,
    },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);
shopSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: "all" });
module.exports = mongoose.model("Shops", shopSchema);
