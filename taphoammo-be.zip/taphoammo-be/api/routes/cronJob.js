const cron = require('node-cron');
const Transactions = require('../../database/entities/Transactions');
const Users = require('../../database/entities/Users');
const moment = require('moment');
const { TRANSACTION_TYPE, TRANSACTION_STATUS } = require('../../constants/enum');


// cron cong tien cho nguoi ban ( sau 3 ngay khi don hang hoan thanh va khong co khieu nai)
cron.schedule('*/1 * * * *', async () => {
    const transactions = await Transactions.aggregate([
        {
            $match: {
                $and: [
                    { createdAt: { $lte: moment().subtract(3, 'days').toDate() } },
                    { deleted: false },
                    { type: TRANSACTION_TYPE.ORDER }
                ]
            },
        },
        {
            $lookup: {
                from: 'complains',
                localField: 'orderId',
                foreignField: 'orderId',
                as: 'complains'
            }
        },
        {
            $match: { complains: { $eq: [] } }
        }
    ]);
    if (transactions.length) {
        const transactionIds = [];
        await Promise.all(transactions.map(async x => {
            await Users.findByIdAndUpdate(x.sellerId, { $inc: { balance: x.value } });
            transactionIds.push(x._id);
        }));
        await Transactions.updateMany({ _id: { $in: transactionIds } }, { $set: { deleted: true } });
    }

});
