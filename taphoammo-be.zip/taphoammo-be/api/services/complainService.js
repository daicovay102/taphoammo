const Complain = require('../../database/entities/Complain');
const { isValidObjectId } = require('mongoose');

const getById = async (id) => {
    return await Complain.findOneWithDeleted({ _id: isValidObjectId(id) ? id : null });
};
const getAll = async () => {
    return Complain.find().sort({ createdAt: 'desc' });
};

const getPaging = async (query,) => {
    const pageSize = Number.parseInt(query.pageSize) || 10;
    const pageIndex = Number.parseInt(query.pageIndex) || 1;
    const searchObj = {};

    if (query.shopId) {
        searchObj.shopId = isValidObjectId(query.shopId) ? query.shopId : null;
    }
    if (query.createdBy) {
        searchObj.createdBy = isValidObjectId(query.createdBy) ? query.createdBy : null;
    }
    if (query.orderId) {
        searchObj.orderId = isValidObjectId(query.orderId) ? query.orderId : null;
    }
    const [data, count] = await Promise.all([
        Complain.find(searchObj)
            .sort({ createdAt: 'desc' })
            .skip(pageSize * pageIndex - pageSize)
            .limit(pageSize)
            .populate('createdBy shopId productId'),
        Complain.countDocuments(searchObj)
    ]);
    return { pageIndex, pageSize, count, data };
};

const update = async (id, body) => {
    const { content } = body;
    return Complain.findByIdAndUpdate(id, {
        content,
    }, { new: true });
};

const deleteById = async (id, userId) => {
    return Complain.deleteOne({ '$and': [{ _id: id }, { createdBy: userId }] });
};

const getOne = async (filter) => {
    return Complain.findOne(filter);
};

module.exports = { getById, getAll, getPaging, update, deleteById, getOne };