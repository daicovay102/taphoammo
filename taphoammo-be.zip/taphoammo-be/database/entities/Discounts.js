require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const { DISCOUNT_TYPE } = require('../../constants/enum');
const { Schema } = mongoose;

let discountSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    code: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        index: true,
    },
    description: {
        type: String,
        required: true,
        trim: true
    },
    type: {
        type: Number,
        required: true,
        default: DISCOUNT_TYPE.PHAN_TRAM
    },
    // giam gia theo phan tram
    percentage: {
        type: Number,
        required: true,
        min: 0,
        max: 100
    },
    maxPriceValue: {
        type: Number,
        default: 0
    },
    // giam gia theo gia tri
    value: {
        type: Number,
        default: 0
    },
    numberOfUses: {
        type: Number,
        default: 0
    },
    leftOfUses: {
        type: Number,
        default: 0
    },
    startDate: {
        type: Date,
        required: true
    },
    endDate: {
        type: Date,
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops'
    }
}, {
    versionKey: false,
    timestamps: true
});
discountSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Discounts', discountSchema);
