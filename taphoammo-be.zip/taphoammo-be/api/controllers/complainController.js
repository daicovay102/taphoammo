const complainService = require('../services/complainService');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const ResponseModel = require('../models/ResponseModel');
const PagedModel = require('../models/PagedModel');
const Orders = require('../../database/entities/Orders');
const Complain = require('../../database/entities/Complain');
const { ORDER_STATUS } = require('../../constants/enum');
const moment = require('moment');

const insert = async (req, res) => {
    try {
        const { orderId } = req.body;
        const order = await Orders.findById(orderId, { _id: 1, shopId: 1, createdAt: 1, productId: 1 });
        if (!order) {
            return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Order not found', null));
        }
        if (moment(order.createdAt).add(3, 'days').isBefore(moment())) {
            return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Quá thời gian khiếu nại', null));
        }
        const isExist = await complainService.getOne({ createdBy: req.userId, orderId });
        if (isExist) {
            return res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'You have complain this order before', null));
        }
        console.log(order.productId);
        const [result] = await Promise.all([
            Complain.create({
                orderId,
                content: req.body.content,
                shopId: order.shopId,
                createdBy: req.userId,
                productId: order.productId
            }),
            Orders.findByIdAndUpdate(orderId, { $set: { status: ORDER_STATUS.KHIEU_NAI } })
        ]);
        return res.json(new ResponseModel(HTTP_STATUS.OK, 'Create order complain success', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const getById = async (req, res) => {
    try {
        const result = await complainService.getById(req.params.id);
        return res.json(new ResponseModel(HTTP_STATUS.OK, 'Get order complain success', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const getAll = async (req, res) => {
    try {
        const reviews = await complainService.getAll();
        return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'Get all order complain success', reviews));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getPaging = async (req, res) => {
    try {
        const { pageIndex, pageSize, count, data } = await complainService.getPaging(req.query);
        return res.json(new PagedModel(pageIndex, pageSize, count, data));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const update = async (req, res) => {
    try {
        const { id } = req.body;
        const review = await complainService.getById(id);
        if (!review) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Order complain not found', null));
        } else {
            const result = await complainService.update(id, req.body);
            res.json(new ResponseModel(1, 'Update Order complain success', result));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }

};

const deleteById = async (req, res) => {
    try {
        const review = await complainService.getById(req.params.id);
        if (!review) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'Order complain not found', null));
        } else {
            const result = await complainService.deleteById(req.params.id, req.userId);
            res.json(new ResponseModel(1, 'Delete Order complain success', result));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

module.exports = { insert, getById, getAll, getPaging, update, deleteById };