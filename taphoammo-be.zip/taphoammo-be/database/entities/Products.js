require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const slug = require('mongoose-slug-generator');
const { PRODUCT_STATUS } = require('../../constants/enum');
mongoose.plugin(slug);

const { Schema } = mongoose;

let productSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    name: {
        type: String,
        required: true
    },
    slug: {
        type: String,
        slug: 'name',
        unique: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    quantity: {
        type: Number,
        default: 0
    },
    price: {
        type: Number,
        required: true
    },
    status: {
        type: Number,
        default: PRODUCT_STATUS.Accepted
    },
    soldQuantity: {
        type: Number,
        default: 0
    },
    productTypeId: {
        type: Schema.Types.ObjectId,
        ref: 'Product_types',
        required: true
    },
    businessTypeId: {
        type: Schema.Types.ObjectId,
        ref: 'Business_types',
        required: true
    },
    shopTypeId: {
        type: Schema.Types.ObjectId,
        ref: 'Shop_types',
        required: true
    }
}, {
    versionKey: false,
    timestamps: true
});
productSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Products', productSchema);
