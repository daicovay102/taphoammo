const Discounts = require('../../database/entities/Discounts');
const { isValidObjectId } = require('mongoose');

const insert = async (body, userId) => {
    return await Discounts.create({
        createdBy: userId,
        code: body.code.toLowerCase(),
        ...body,
        leftOfUses: body.numberOfUses
    });
};

const getById = async (id) => {
    return await Discounts.findOneWithDeleted({ _id: isValidObjectId(id) ? id : null });
};
const getAll = async () => {
    return Discounts.find().sort({ createdAt: 'desc' });
};

const getPaging = async (query) => {
    const pageSize = Number.parseInt(query.pageSize) || 10;
    const pageIndex = Number.parseInt(query.pageIndex) || 1;
    let searchObj = {};

    if (query.search) {
        searchObj = {
            $or: [
                { name: { $regex: new RegExp(query.search, 'i') } },
                { description: { $regex: new RegExp(query.search, 'i') } }
            ]
        };
    }
    const [data, count] = await Promise.all([
        Discounts.find(searchObj)
            .skip(pageSize * pageIndex - pageSize)
            .limit(pageSize)
            .sort({ createdAt: 'desc' }),
        Discounts.countDocuments(searchObj)
    ]);
    return { pageIndex, pageSize, count, data };
};

const update = async (id, body) => {
    const { name, value, description } = body;
    return Discounts.findByIdAndUpdate(id, {
        name, value, description,
    }, { new: true });
};

const deleteById = async (id) => {
    return Discounts.findByIdAndDelete(id);
};

const getOne = async (filter) => {
    return Discounts.findOne(filter);
};

module.exports = { insert, getById, getAll, getPaging, update, deleteById, getOne };