const express = require('express');
const router = express.Router();
const middlewares = require('../middlewares');
const shopReviewController = require('../../controllers/shopReviewController');
const {
    reviewShopValidator,
    getByIdValidator,
    getPagingValidator
} = require('../../middlewares/shopReviewMiddlewares');

router.post('/insert', reviewShopValidator, middlewares.authorizeAdmin, shopReviewController.reviewShop);

router.get('/getAll', middlewares.authorizeAdmin, shopReviewController.getAll);

router.get('/getPaging', getPagingValidator, middlewares.authorizeAdmin, shopReviewController.getPaging);

router.get('/getById/:id', getByIdValidator, middlewares.authorizeAdmin, shopReviewController.getById);

module.exports = router;