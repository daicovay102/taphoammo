const express = require('express');
const router = express.Router();
const productImportController = require('../controllers/productImportController');
const middlewares = require('./middlewares');
const { fileUpload, imageUpload } = require('./upload');

router.get('/getAll', middlewares.authorize, productImportController.getAll);

router.get('/getPaging', middlewares.authorize, productImportController.getPaging);

router.delete('/deleteStatusActive', middlewares.authorize, productImportController.deleteStatusActive);

router.delete('/delete-by-product', middlewares.authorize, productImportController.deleteProductImport);

module.exports = router;