require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const { SERVICE_STATUS } = require('../../constants/enum');
const { Schema } = mongoose;

let serviceSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    name: {
        type: String,
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    quantity: {
        type: Number,
        default: 0
    },
    price: {
        type: Number,
        default: 0
    },
    status: {
        type: Number,
        default: SERVICE_STATUS.Pending
    }
}, {
    versionKey: false,
    timestamps: true
});
serviceSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Services', serviceSchema);
