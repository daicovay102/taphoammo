const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const middlewares = require('./middlewares');

router.post('/insert', middlewares.authorize, productController.insert);
router.put('/update/:id', middlewares.authorize, productController.update);
router.delete(
    '/delete/:id',
    middlewares.authorize,
    productController.deleteById
);
router.get('/getAll', productController.getAll);
router.get('/getById/:id', productController.getById);
router.post('/getPaging', productController.getPaging);
module.exports = router;
