const { config } = require("dotenv");
const jwt = require("jsonwebtoken");
config();

exports.signToken = ({
  payload,
  privateKey,
  options = {
    algorithm: "HS256",
  },
}) => {
  return new Promise((resolve, reject) => {
    jwt.sign(payload, privateKey, options, (error, token) => {
      if (error) {
        throw reject(error);
      }
      resolve(token);
    });
  });
};

exports.verifyToken = ({
  token,
  secretOrPublicKey = process.env.JWT_SECRET,
}) => {
  return new Promise((resolve, reject) => {
    jwt.verify(token, secretOrPublicKey, (error, decodes) => {
      if (error) {
        throw reject(error);
      }
      resolve(decodes);
    });
  });
};
