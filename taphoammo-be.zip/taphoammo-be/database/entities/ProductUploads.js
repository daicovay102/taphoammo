require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const slug = require('mongoose-slug-generator');
mongoose.plugin(slug);
const { Schema } = mongoose;

let productUploadSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    name: {
        type: String,
        required: true
    },
    nameFile: {
        type: String,
        required: true
    },
    filePath: {
        type: String,
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    productId: {
        type: Schema.Types.ObjectId,
        ref: 'Products',
        required: true
    },
    result: {
        total: {type: Number, default: 0},
        success: {type: Number, default: 0},
        error: {type: Number, default: 0}
    },
    status: {
        type: Number,
        default: 0
    }
}, {
    versionKey: false,
    timestamps: true
});
productUploadSchema.plugin(mongoose_delete, { deletedAt : true, overrideMethods: 'all'});
module.exports = mongoose.model('Product_uploads', productUploadSchema)
