require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const { Schema } = mongoose;

const shopReviewHistoriesSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    status: {
        type: Number,
        required: true,
    }
}, {
    versionKey: false,
    timestamps: true
});
shopReviewHistoriesSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Shop_review_histories', shopReviewHistoriesSchema)
