const express = require('express');
const router = express.Router();
const productUploadController = require('../controllers/productUploadController');
const middlewares = require('./middlewares');
const { fileUpload, imageUpload } = require('./upload');

router.post('/insert', middlewares.authorize,fileUpload.single("file"), productUploadController.insert);
router.get('/getAll', middlewares.authorize, productUploadController.getAll);
router.get('/getPaging', middlewares.authorize, productUploadController.getPaging);

module.exports = router;