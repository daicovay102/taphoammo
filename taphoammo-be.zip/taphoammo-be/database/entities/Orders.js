require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const uuid = require('uuid');
const { ORDER_STATUS } = require('../../constants/enum');
const { Schema } = mongoose;

let orderSchema = new Schema({
    uid: { type: String, default: uuid.v4() },
    buyerId: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    sellerId: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    productId: {
        type: Schema.Types.ObjectId,
        ref: 'Products',
        required: true
    },
    productTypeId: {
        type: Schema.Types.ObjectId,
        ref: 'Product_types',
        required: true
    },
    businessTypeId: {
        type: Schema.Types.ObjectId,
        ref: 'Business_types',
        required: true
    },
    shopTypeId: {
        type: Schema.Types.ObjectId,
        ref: 'Shop_types',
        required: true
    },
    name: {
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true,
    },
    price: {
        type: Number,
        required: true
    },
    discount: {
        type: Number,
        required: true
    },
    totalPayment: {
        type: Number,
        required: true
    },
    status: {
        type: Number,
        default: ORDER_STATUS.DOI_CHAP_THUAN
    },
    orderDuration: {
        type: Number,
        default: null,
        required: false
    },
    productImportIds: [{ type: Schema.Types.ObjectId, ref: 'Product_imports' }],
    trackingAmount: {
        totalAmount: {
            type: Number,
            default: 0,
            required: true
        },
        amountAfterAppliedDiscount: {
            type: Number,
            default: 0,
            required: true
        },
        amountBuyerPay: {
            type: Number,
            default: 0,
            required: true
        },
        amountForMerchant: {
            type: Number,
            default: 0,
            required: true
        },
        amountFee: {
            type: Number,
            default: 0,
            required: true
        }
    }
}, {
    versionKey: false,
    timestamps: true
});
orderSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Order', orderSchema);
