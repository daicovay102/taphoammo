const express = require('express');
const router = express.Router();
const shopEvaluationController = require('../controllers/shopEvaluationController');
const middlewares = require('./middlewares');
const {
    createValidator,
    getPagingValidator,
    getByIdValidator,
    updateValidator
} = require('../middlewares/shopEvaluationMiddlewares');

router.post('/insert', createValidator, middlewares.authorize, shopEvaluationController.insert);

router.get('/getAll', shopEvaluationController.getAll);

router.get('/getPaging', getPagingValidator, shopEvaluationController.getPaging);

router.get('/getById/:id', getByIdValidator, shopEvaluationController.getById);

router.delete('/delete/:id', getByIdValidator, middlewares.authorizeAdmin, shopEvaluationController.deleteById);

router.patch('/update', updateValidator, middlewares.authorize, shopEvaluationController.update);

module.exports = router;