const ResponseModel = require("../models/ResponseModel");
const fs = require("fs");
const path = require("path");

async function uploadImage(req, res) {
  try {
    if (!req.file) {
      let response = new ResponseModel(-2, "No image uploaded!", null);
      res.json(response);
    }
    const path_image = "uploads/images/";
    const fileName = `${path_image}${req.file.filename}`;

    let response = new ResponseModel(1, "Upload image successfully!", {
      imageName: fileName,
    });
    res.json(response);
  } catch (error) {
    let response = new ResponseModel(404, error.message, error);
    res.status(404).json(response);
  }
}

async function deleteImage(req, res) {
  try {
    const imageName = req.params.id;
    const imagePath = path.join(
      __dirname,
      "../..",
      "/uploads/images",
      imageName
    );

    if (!fs.existsSync(imagePath)) {
      let response = new ResponseModel(0, "Image item not found!", null);
      res.json(response);
    } else {
      fs.unlinkSync(imagePath);

      let response = new ResponseModel(1, "Image deleted successfully!", null);
      res.json(response);
    }
  } catch (error) {
    let response = new ResponseModel(404, error.message, error);
    res.status(404).json(response);
  }
}

async function uploadFile(req, res) {
  try {
    if (!req.file) {
      let response = new ResponseModel(-2, "No File uploaded!", null);
      res.json(response);
    }
    const path_file = "uploads/files/";
    const fileName = `${path_file}${req.file.filename}`;

    let response = new ResponseModel(1, "Upload File successfully!", {
      fileName: fileName,
    });
    res.json(response);
  } catch (error) {
    let response = new ResponseModel(404, error.message, error);
    res.status(404).json(response);
  }
}

async function deleteFile(req, res) {
  try {
    const fileName = req.params.id;
    const filePath = path.join(__dirname, "../..", "/uploads/files", fileName);

    if (!fs.existsSync(filePath)) {
      let response = new ResponseModel(0, "File not item found!", null);
      res.json(response);
    } else {
      fs.unlinkSync(filePath);

      let response = new ResponseModel(1, "File deleted successfully!", null);
      res.json(response);
    }
  } catch (error) {
    let response = new ResponseModel(404, error.message, error);
    res.status(404).json(response);
  }
}

module.exports = {
  uploadImage,
  deleteImage,
  uploadFile,
  deleteFile,
};
