const express = require('express');
const router = express.Router();
const complainController = require('../controllers/complainController');
const middlewares = require('./middlewares');
const {
    createValidator,
    getPagingValidator,
    getByIdValidator,
    updateValidator
} = require('../middlewares/complainMiddlewares');

router.post('/insert', createValidator, middlewares.authorize, complainController.insert);

router.get('/getAll', complainController.getAll);

router.get('/getPaging', getPagingValidator, complainController.getPaging);

router.get('/getById/:id', getByIdValidator, complainController.getById);

router.delete('/delete/:id', getByIdValidator, middlewares.authorizeAdmin, complainController.deleteById);

router.patch('/update', updateValidator, middlewares.authorize, complainController.update);

module.exports = router;