require('../database');
const mongoose = require('mongoose');
const slug = require('mongoose-slug-generator');
const { PRODUCT_IMPORT_STATUS } = require('../../constants/enum');
mongoose.plugin(slug);
const { Schema } = mongoose;

let productImportSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    name: {
        type: String,
        required: true
    },
    filePath: {
        type: String,
        required: true
    },
    productId: {
        type: Schema.Types.ObjectId,
        ref: 'Products',
        required: true
    },
    productTypeId: {
        type: Schema.Types.ObjectId,
        ref: 'Product_types',
        required: true
    },
    productUploadId: {
        type: Schema.Types.ObjectId,
        ref: 'Product_uploads',
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    sellerBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users'
    },
    sellerAt: {
        default: '',
        type: Date
    },
    status: {
        type: Number,
        default: PRODUCT_IMPORT_STATUS.PENDING,
        enum: Object.values(PRODUCT_IMPORT_STATUS)
    }
}, {
    versionKey: false,
    timestamps: true
});

module.exports = mongoose.model('Product_imports', productImportSchema);
