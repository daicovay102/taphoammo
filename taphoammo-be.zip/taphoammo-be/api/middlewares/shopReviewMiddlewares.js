const { checkSchema } = require('express-validator');
const { validate, checkObjectIdOptions } = require('../../utilities/validation');
const { SHOP_STATUS } = require('../../constants/enum');

const reviewShopValidator = validate(
    checkSchema(
        {
            shopId: {
                trim: true,
                custom: { options: checkObjectIdOptions('shopId') },
            },
            status: {
                isIn: {
                    options: [Object.values(SHOP_STATUS)],
                    errorMessage: `Status wrong. Must be one of ${Object.values(SHOP_STATUS)}`
                },
            }
        },
        ['body']
    )
);


const getByIdValidator = validate(
    checkSchema(
        {
            id: {
                trim: true,
                custom: { options: checkObjectIdOptions('id') },
            },

        },
        ['params']
    )
);

const getPagingValidator = validate(
    checkSchema(
        {
            pageSize: { isInt: { options: { min: 1 } } },
            pageIndex: { isInt: { options: { min: 1 } } }
        },
        ['query']
    )
);


module.exports = { reviewShopValidator, getByIdValidator, getPagingValidator };