const express = require('express');
const router = express.Router();
const serviceController = require('../controllers/serviceController');
const middlewares = require('./middlewares');

router.post('/insert', middlewares.authorize, serviceController.insert);
router.put('/update/:id', middlewares.authorize, serviceController.update);
router.delete('/delete/:id', middlewares.authorize, serviceController.deleteById);
router.get('/getAll', middlewares.authorize, serviceController.getAll);
router.get('/getById/:id', middlewares.authorize, serviceController.getById);
router.get('/getPaging', middlewares.authorize, serviceController.getPaging);
module.exports = router;