const { HTTP_STATUS } = require('../../constants/httpStatus');
const ResponseModel = require('../models/ResponseModel');
const shopReviewService = require('../services/shopReviewService');
const PagedModel = require('../models/PagedModel');
const Shops = require('../../database/entities/Shops');

const reviewShop = async (req, res) => {
    try {
        const { shopId, status } = req.body;
        const shop = await Shops.findById(shopId);
        if (!shop) {
            const response = new ResponseModel(
                HTTP_STATUS.BAD_REQUEST,
                'Shop not found',
                null
            );
            return res.status(HTTP_STATUS.BAD_REQUEST).json(response);
        }
        const result = await shopReviewService.reviewShop(
            req.userId,
            status,
            shopId
        );
        return res.status(HTTP_STATUS.OK).json(
            new ResponseModel(HTTP_STATUS.OK, 'Review shop success', {
                shopId,
                result,
            })
        );
    } catch (error) {
        res
            .status(HTTP_STATUS.INTERNAL_SERVER_ERROR)
            .json(
                new ResponseModel(
                    HTTP_STATUS.INTERNAL_SERVER_ERROR,
                    error.message,
                    error
                )
            );
    }
};

const getAll = async (req, res) => {
    try {
        const reviews = await shopReviewService.getAll();
        return res
            .status(HTTP_STATUS.OK)
            .json(
                new ResponseModel(
                    HTTP_STATUS.OK,
                    'Get all review shop success',
                    reviews
                )
            );
    } catch (e) {
        res
            .status(HTTP_STATUS.INTERNAL_SERVER_ERROR)
            .json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getPaging = async (req, res) => {
    try {
        const { pageIndex, pageSize, count, data } =
            await shopReviewService.getPaging(req.query, req.userId);
        return res.json(new PagedModel(pageIndex, pageSize, count, data));
    } catch (e) {
        res
            .status(HTTP_STATUS.INTERNAL_SERVER_ERROR)
            .json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getById = async (req, res) => {
    try {
        const result = await shopReviewService.getById(req.params.id);
        return res.json(
            new ResponseModel(HTTP_STATUS.OK, 'Get review shop success', result)
        );
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

module.exports = { reviewShop, getAll, getPaging, getById };
