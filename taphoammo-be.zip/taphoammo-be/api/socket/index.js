const userService = require("./../services/userService");
const chatService = require("./../services/chatService");
const { isValidObjectId } = require("mongoose");
const jwt = require("jsonwebtoken");
require("dotenv").config();
const secretKey = process.env.JWT_SECRET_ACCESS_TOKEN;

module.exports = function(io) {
    io
    .use(function(socket, next){
    	
		if (socket.handshake.query && socket.handshake.query.token){
			jwt.verify(socket.handshake.query.token, secretKey, function(err, decoded) {
			  	if (err) return next(new Error('Authentication error'));
		  		socket.userId = decoded?.user._id;
		  		next();
			});
		}
		else {
			next(new Error('Authentication error'));
		}    
	})
    .on('connection',async function(socket) {
    	if (isValidObjectId(socket.userId)) {
        	await userService.updateIsOnline(socket.userId, true);
        }
        require('./../controllers/chatController').inforSocket(socket, io);

        socket.on('disconnect',async function() {
        	if (isValidObjectId(socket.userId)) {
        		await userService.updateIsOnline(socket.userId, false);
        	}
        });

        //socket join room 
        socket.on('joinRoom', function(room) {
	        socket.join(room);
	    });
        //send message in room

        socket.on('ChatMessage',async function(data) {
        	if (isValidObjectId(data.room)) {
        		io.to(data.room).emit('ChatMessage', data);
        		await chatService.message({'chatId': data.room, message: data.message} , socket.userId)
        	}
	    });
    });
}