const express = require('express');
const router = express.Router();
const shopController = require('../controllers/shopController');
const middlewares = require('./middlewares');

router.post('/insert', middlewares.authorize, shopController.insert);
router.put('/update/:id', middlewares.authorize, shopController.update);
router.delete('/delete/:id', middlewares.authorize, shopController.deleteById);
router.get('/getAll', shopController.getAll);
router.get('/getById/:id', shopController.getById);
router.get('/getBySlug/:slug', shopController.getBySlug);
router.get('/getPaging', shopController.getPaging);

module.exports = router;