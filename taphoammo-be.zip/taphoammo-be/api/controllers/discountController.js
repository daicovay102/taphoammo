const { HTTP_STATUS } = require('../../constants/httpStatus');
const ResponseModel = require('../models/ResponseModel');
const PagedModel = require('../models/PagedModel');
const discountService = require('../services/discountService');
const Discounts = require('../../database/entities/Discounts');
const Users = require('../../database/entities/Users');

const insert = async (req, res) => {
    try {
        const exist = await Discounts.findOne({ code: req.body.code.toLowerCase() });
        if (exist) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'MA GIAM GIA DA TON TAI', null));
        }

        const user = await Users.findById(req.userId);
        if (user.balance <= 0) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'KHONG DU SO DU', null));
        }
        const result = await discountService.insert(req.body, req.userId);
        return res.json(new ResponseModel(HTTP_STATUS.OK, 'Create discount success', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const getById = async (req, res) => {
    try {
        const result = await discountService.getById(req.params.id);
        return res.json(new ResponseModel(HTTP_STATUS.OK, 'Get discount success', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const getAll = async (req, res) => {
    try {
        const reviews = await discountService.getAll();
        return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'Get all discount success', reviews));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const getPaging = async (req, res) => {
    try {
        const { pageIndex, pageSize, count, data } = await discountService.getPaging(req.query);
        return res.json(new PagedModel(pageIndex, pageSize, count, data));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

const update = async (req, res) => {
    try {
        const { id } = req.body;
        const review = await discountService.getById(id);
        if (!review) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'discount not found', null));
        } else {
            const result = await discountService.update(id, req.body);
            res.json(new ResponseModel(1, 'Update discount success', result));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }

};

const deleteById = async (req, res) => {
    try {
        const review = await discountService.getById(req.params.id);
        if (!review) {
            res.status(HTTP_STATUS.BAD_REQUEST).json(new ResponseModel(0, 'discount not found', null));
        } else {
            const result = await discountService.deleteById(req.params.id, req.userId);
            res.json(new ResponseModel(1, 'Delete discount success', result));
        }
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};

module.exports = { insert, getById, getAll, getPaging, update, deleteById };