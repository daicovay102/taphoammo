const { HTTP_STATUS } = require('../../constants/httpStatus');
const ResponseModel = require('../models/ResponseModel');
const chatService = require('../services/chatService');
const info = {
    socket: null,
    io: null,
    get sockets() {
        return {
            socket: this.socket,
            io: this.io
        };
    },
    set sockets(infoSocket) {
        this.socket = infoSocket[0] || null;
        this.io = infoSocket[1] || null;
    }
};

const insert = async (req, res) => {
    try {
        const result = await chatService.insert(req.body, req.userId);
        if (result) {
            return res.json(new ResponseModel(HTTP_STATUS.OK, 'Create chat success', result));
        } else {
            const status = HTTP_STATUS.NOT_FOUND;
            res.status(status).json(new ResponseModel(status, 'Create chat error', null));
        }
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};

const getAll = async (req, res) => {
    try {

        const reviews = await chatService.getAll(req.userId);
        return res.status(HTTP_STATUS.OK).json(new ResponseModel(HTTP_STATUS.OK, 'Get all chat evaluation success', reviews));
    } catch (e) {
        res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(new ResponseModel(HTTP_STATUS.INTERNAL_SERVER_ERROR, e.message, e));
    }
};
const message = async (req, res) => {
    try {
        const result = await chatService.message(req.body, req.userId);
        if (result)
            return res.json(new ResponseModel(HTTP_STATUS.OK, 'Message chat success', result));
        else
            return res.json(new ResponseModel(HTTP_STATUS.NOT_FOUND, 'Chat not found', result));
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
};
const inforSocket = (socket, io) => {
    info.sockets = [socket, io];
};
module.exports = { insert, getAll, message, inforSocket };