const { isValidObjectId } = require('mongoose');
const Users = require('../../database/entities/Users');
const { responseError, responseSuccess } = require('../../utilities/statusRes');
const PagedModel = require('../models/PagedModel');
const ResponseModel = require('../models/ResponseModel');
const userService = require('../services/userService');
const { USER_ROLE } = require('../../constants/enum');
require('dotenv').config();

async function login(req, res) {
    try {
        const { user } = req;
        const { userToken } = req.body;
        const dataRes = await userService.login(user, userToken);
        return responseSuccess(res, 'Đăng nhập thành công.', dataRes);
    } catch (error) {
        responseError(res, error);
    }
}

async function loginAdmin(req, res) {
    try {
        const { user } = req;
        const { userToken } = req.body;
        const dataRes = await userService.login(user, userToken);
        if (dataRes.user.role !== USER_ROLE.Admin) {
            return responseError(res, { message: 'Unauthorised' });
        }
        return responseSuccess(res, 'Đăng nhập thành công.', dataRes);
    } catch (error) {
        responseError(res, error);
    }
}


async function insertUser(req, res) {
    try {
        const payload = req.body;
        const user = await userService.insert(payload);
        return responseSuccess(res, 'Thêm mới người dùng thành công.', {
            id: user._id,
            email: user.email,
            role: user.role,
            userName: user.userName,
            phoneNumber: user.phoneNumber,
            avatar: user.avatar,
            fullName: user.fullName,
        });
    } catch (error) {
        responseError(res, error);
    }
}

async function logout(req, res) {
    try {
        const { refreshToken } = req.body;
        await userService.logout(refreshToken);
        return responseSuccess(res, 'Đăng xuất thành công', null);
    } catch (error) {
        responseError(res, error);
    }
}

async function register(req, res) {
    try {
        const dataRes = await userService.register(req.body);
        return responseSuccess(res, 'Đăng ký thành công.', dataRes);
    } catch (error) {
        responseError(res, error);
    }
}

async function getPaging(req, res) {
    try {
        const { pageIndex, pageSize, count, data } = await userService.getPaging(
            req.query
        );
        return res.json(new PagedModel(pageIndex, pageSize, count, data));
    } catch (error) {
        responseError(res, error);
    }
}

async function getAllUsers(req, res) {
    const users = await Users.find({}).sort({ createdAt: 'desc' });
    const response = new ResponseModel(1, 'Lấy dữ liệu thành công.', users);
    res.json(response);
}

async function getUserById(req, res) {
    if (req.params.id) {
        try {
            let user = await Users.findById(req.params.id);
            const response = new ResponseModel(1, 'Lấy dữ liệu thành công.', user);
            res.json(response);
        } catch (error) {
            let response = new ResponseModel(-2, error.message, error);
            res.json(response);
        }
    } else {
        res.sendStatus(403);
    }
}

async function deleteUser(req, res) {
    try {
        const userId = req.params.id;
        if (!isValidObjectId(userId)) {
            return res
                .status(404)
                .json(new ResponseModel(404, 'UserId is not valid!', null));
        }

        const user = await Users.findById(userId);
        if (!user) {
            return res.json(new ResponseModel(0, 'No item found!', null));
        }

        await user.remove();

        return res.json(new ResponseModel(1, 'Delete user success!', null));
    } catch (error) {
        const response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

async function deleteManyUsers(req, res) {
    try {
        const deleteResults = [];
        const userIds = req.body.ids;

        if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
            res
                .status(400)
                .json(
                    new ResponseModel(
                        400,
                        'Invalid request body. \'ids\' array is required.',
                        null
                    )
                );
            return;
        }

        if (!userIds.every(isValidObjectId)) {
            res
                .status(400)
                .json(
                    new ResponseModel(400, 'One or more UserIds are not valid!', null)
                );
            return;
        }

        const updateResult = await Users.deleteMany({ _id: { $in: userIds } });

        if (updateResult.deletedCount === 0) {
            res.json(
                new ResponseModel(200, 'No users found for deletion!', deleteResults)
            );
        } else {
            res.json(new ResponseModel(200, 'Users deletion results:', updateResult));
        }
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}

async function updateUser(req, res) {
    try {
        const payload = req.body;
        const userId = req.params.id;
        await userService.update(payload, userId);
        return responseSuccess(res, 'Cập nhập người dùng thành công', null);
    } catch (error) {
        responseError(res, error);
    }
}

async function forgotPassword(req, res) {
    try {
        const dataRes = await userService.forgotPassword(req.user);
        return responseSuccess(
            res,
            'Vui lòng kiểm tra email để lấy đường dẫn thay đổi mật khẩu mới',
            dataRes
        );
    } catch (error) {
        responseError(res, error);
    }
}

async function verifyForgotPassword(req, res) {
    return responseSuccess(res, 'Xác thực quên mật khẩu thành công', null);
}

async function resetPassword(req, res) {
    try {
        const { userId } = req.decodeForgotPasswordToken;
        const { password } = req.body;
        await userService.resetPassword(userId, password);
        return responseSuccess(res, 'Thay đổi mật khẩu thành công.', null);
    } catch (error) {
        responseError(res, error);
    }
}

async function changePassword(req, res) {
    try {
        const { userId } = req;
        const { password } = req.body;
        await userService.changePassword(userId, password);
        return responseSuccess(res, 'Thay đổi mật khẩu thành công.', null);
    } catch (error) {
        responseError(res, error);
    }
}

async function getMe(req, res) {
    try {
        const { userId } = req;
        const dataRes = await userService.getMe(userId);
        return responseSuccess(
            res,
            'Lấy thông tin người dùng thành công.',
            dataRes
        );
    } catch (error) {
        responseError(res, error);
    }
}

async function oauth(req, res) {
    try {
        const { code } = req.query;
        const dataRes = await userService.oauth(code);
        return responseSuccess(res, 'Đăng nhập bằng google thành công.', dataRes);
    } catch (error) {
        responseError(res, error);
    }
}

async function enable2FA(req, res) {
    try {
        const { userId } = req;
        const dataRes = await userService.enable2FA(userId);
        return responseSuccess(res, 'Lấy mã QR thành công.', dataRes);
    } catch (error) {
        responseError(res, error);
    }
}

async function verify2Fa(req, res) {
    try {
        const { userId } = req;
        await userService.verify2FA(userId);
        return responseSuccess(res, 'Xác nhận mã đăng nhập thành công.', null);
    } catch (error) {
        responseError(res, error);
    }
}

async function disable2Fa(req, res) {
    try {
        const { userId } = req;
        await userService.disable2Fa(userId);
        return responseSuccess(res, 'Tắt xác thực 2FA thành công', null);
    } catch (error) {
        responseError(res, error);
    }
}

module.exports = {
    login,
    insertUser,
    getAllUsers,
    getUserById,
    register,
    deleteUser,
    deleteManyUsers,
    updateUser,
    getPaging,
    logout,
    forgotPassword,
    verifyForgotPassword,
    resetPassword,
    changePassword,
    getMe,
    oauth,
    enable2FA,
    verify2Fa,
    disable2Fa,
    loginAdmin
};
