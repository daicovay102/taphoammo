const express = require('express');
const router = express.Router();
const productTypeController = require('../controllers/productTypeController');
const middlewares = require('./middlewares');

router.post('/insert', middlewares.authorizeAdmin, productTypeController.insert);
router.put('/update/:id', middlewares.authorizeAdmin, productTypeController.update);
router.delete('/delete/:id', middlewares.authorizeAdmin, productTypeController.deleteById);
router.delete('/deleteMany', middlewares.authorizeAdmin, productTypeController.deleteMany);
router.get('/getAll', productTypeController.getAll);
router.get('/getById/:id', productTypeController.getById);
router.get('/getPaging', productTypeController.getPaging);

module.exports = router;