const express = require('express');
const router = express.Router();
const middlewares = require('./middlewares');
const uploadController = require('../controllers/uploadController');
const { fileUpload, imageUpload } = require('./upload');

router.post('/image', middlewares.authorize, imageUpload.single("image"), uploadController.uploadImage);
router.delete('/delete/image/:id',middlewares.authorize, uploadController.deleteImage);
router.post('/file', middlewares.authorize, fileUpload.single("file"), uploadController.uploadFile);
router.delete('/delete/file/:id', middlewares.authorize, uploadController.deleteFile);

module.exports = router;
