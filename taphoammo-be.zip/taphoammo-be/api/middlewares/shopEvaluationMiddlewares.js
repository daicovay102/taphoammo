const { validate, checkObjectIdOptions } = require('../../utilities/validation');
const { checkSchema } = require('express-validator');

const createValidator = validate(
    checkSchema(
        {
            shopId: {
                trim: true,
                custom: { options: checkObjectIdOptions('productId') },
            },
            content: { isString: { options: { min: 20 } }, optional: false },
            reviewPoint: { isFloat: { options: { min: 0, max: 5 } }, optional: false }
        },
        ['body']
    )
);

const getPagingValidator = validate(
    checkSchema(
        {
            pageSize: { isInt: { options: { min: 1 } } },
            pageIndex: { isInt: { options: { min: 1 } } },
            shopId: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('shopId') },
            },
            createdBy: {
                trim: true,
                optional: true,
                custom: { options: checkObjectIdOptions('createdBy') },
            },
        },
        ['query']
    )
);

const getByIdValidator = validate(
    checkSchema(
        {
            id: {
                trim: true,
                custom: { options: checkObjectIdOptions('id') },
            },
        },
        ['params']
    )
);

const updateValidator = validate(
    checkSchema(
        {
            id: {
                trim: true,
                optional: false,
                custom: { options: checkObjectIdOptions('id') },
            },
            content: { isString: { options: { min: 20 } }, optional: false },
            reviewPoint: { isFloat: { options: { min: 0, max: 5 } }, optional: false }
        },
        ['body']
    )
);

module.exports = {
    createValidator,
    getPagingValidator,
    getByIdValidator,
    updateValidator
};