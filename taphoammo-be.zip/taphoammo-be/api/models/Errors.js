module.exports = class ErrorWithStatus {
  constructor({ message, status }) {
    this.message = message;
    this.status = status;
  }
};
