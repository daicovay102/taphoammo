const PagedModel = require('../models/PagedModel');
const ResponseModel = require('../models/ResponseModel');
const productService = require('../services/productService');
const shopService = require('../services/shopService');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const ProductTypes = require('../../database/entities/ProductTypes');
const Products = require('../../database/entities/Products');
const Shops = require('../../database/entities/Shops');
const { isValidObjectId, Types } = require('mongoose');
const { isNotNullAndUndefined } = require('../../utilities/validation');
const { PRODUCT_SORT, SHOP_STATUS } = require('../../constants/enum');

async function insert(req, res) {
    try {
        const { shopId, name, productTypeId, price, quantity } = req.body;
        const checkShop = await Shops.findById(shopId);
        if (!checkShop) {
            return res.json(
                new ResponseModel(-1, 'Gian hàng của bạn không tồn tại!', null)
            );
        }
        if (checkShop.status !== SHOP_STATUS.Accepted) {
            return res.json(
                new ResponseModel(-1, 'Gian hàng của bạn chưa được duyệt!', null)
            );
        }

        const checkName = await productService.checkNameProductByShop(name);
        if (checkName) {
            return res.json(new ResponseModel(-1, 'Mặt hàng này đã tồn tại!', null));
        }

        const checkProductType = await ProductTypes.findById(productTypeId);
        if (!checkProductType) {
            return res.json(
                new ResponseModel(-1, 'Product category không tồn tại!', null)
            );
        }

        const data = await productService.insert(
            {
                ...req.body,
                name: name.trim(),
                shopTypeId: checkProductType.shop_typeId,
                businessTypeId: checkProductType.business_typeId,
                productTypeId,
                price,
                quantity,
            },
            req.userId
        );
        return res.json(new ResponseModel(1, 'Thêm sản phẩm thành công.', data));
    } catch (error) {
        const status = error.status || HTTP_STATUS.INTERNAL_SERVER_ERROR;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getAll(req, res) {
    try {
        const { shopId } = req.query;
        const dataRes = await productService.getAll(shopId ? { shopId } : {});
        return res.json(dataRes);
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getById(req, res) {
    try {
        const dataRes = await productService.getDetailById(req.params.id);
        return res.json(dataRes);
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function getPaging(req, res) {
    try {
        const {
            productTypeIds,
            shopTypeId,
            shopId,
            businessTypeId,
            searchText,
            pageSize,
            pageIndex,
            sort,
        } = req.body;
        const newPageSize = isNotNullAndUndefined(pageSize)
            ? Number.parseInt(pageSize)
            : 10;
        const newPageIndex = isNotNullAndUndefined(pageIndex)
            ? Number.parseInt(pageIndex)
            : 1;

        // searchText với tên SP, slug SP, tên người bán, tên cửa  hàng
        let productSort;
        switch (sort) {
            case PRODUCT_SORT.PHO_BIEN: {
                productSort = { soldQuantity: -1 };
                break;
            }
            case PRODUCT_SORT.GIA_TANG: {
                productSort = { price: 1 };
                break;
            }
            case PRODUCT_SORT.GIA_GIAM: {
                productSort = { price: -1 };
                break;
            }
            default: {
                productSort = { createdAt: -1 };
                break;
            }
        }
        const filters = [{ deleted: false }];
        if (businessTypeId && isValidObjectId(businessTypeId)) {
            filters.push({ businessTypeId: new Types.ObjectId(businessTypeId) });
        }
        if (shopId && isValidObjectId(shopId)) {
            filters.push({ shopId: new Types.ObjectId(shopId) });
        }
        if (shopTypeId && isValidObjectId(shopTypeId)) {
            filters.push({ shopTypeId: new Types.ObjectId(shopTypeId) });
        }
        if (productTypeIds?.length) {
            filters.push({
                productTypeId: {
                    $in: productTypeIds.map((x) => new Types.ObjectId(x)),
                },
            });
        }
        if (searchText) {
            const shops = await Shops.aggregate([
                {
                    $lookup: {
                        from: 'users',
                        localField: 'createdBy',
                        foreignField: '_id',
                        as: 'user',
                    },
                },
                { $unwind: { path: '$user', preserveNullAndEmptyArrays: false } },
                {
                    $match: {
                        $or: [
                            { name: { $regex: new RegExp(searchText, 'i') } },
                            { 'user.userName': { $regex: new RegExp(searchText, 'i') } },
                            { 'user.fullName': { $regex: new RegExp(searchText, 'i') } },
                        ],
                    },
                },
                { $project: { _id: 1 } },
            ]);
            filters.push({
                $or: [
                    { name: { $regex: new RegExp(searchText, 'i') } },
                    { slug: { $regex: new RegExp(searchText, 'i') } },
                    { shopId: { $in: shops.map((x) => x._id) } },
                ],
            });
        }
        const [data, count] = await Promise.all([
            Products.aggregate([
                { $match: { $and: filters } },
                { $sort: productSort },
                { $skip: newPageSize * newPageIndex - newPageSize },
                { $limit: newPageSize },
            ]),
            Products.aggregate([{ $match: { $and: filters } }, { $count: 'count' }]),
        ]);
        return res.json(
            new PagedModel(
                newPageIndex,
                newPageSize,
                count.length ? count[0].count : 0,
                data
            )
        );
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function deleteById(req, res) {
    try {
        const product = await productService.getById(req.params.id);
        if (!product) {
            res.json(new ResponseModel(0, 'Không tìm thấy sản phẩm.', null));
        } else {
            let updated = await productService.deleteById(req.params.id, req.userId);
            if (!updated) {
                res.json(new ResponseModel(0, 'Không tìm thấy sản phẩm ', null));
            } else {
                res.json(new ResponseModel(1, 'Xóa sản phẩm thành công', updated));
            }
        }
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        res.status(status).json(new ResponseModel(status, error.message, error));
    }
}

async function update(req, res) {
    try {
        if (req.body.name) {
            const checkName = await productService.checkNameProductUpdate(
                req.params.id,
                req.body.name
            );
            if (checkName) {
                return res.json(
                    new ResponseModel(-1, 'Mặt hàng này đã tồn tại!', null)
                );
            }
        }
        const updated = await productService.update(
            req.params.id,
            req.body,
            req.userId
        );
        if (!updated) {
            return res.json(new ResponseModel(0, 'Không tìm thấy sản phẩm!', null));
        } else {
            return res.json(
                new ResponseModel(1, 'Cập nhập sản phẩm thành công.', updated)
            );
        }
    } catch (error) {
        const status = error.status || HTTP_STATUS.NOT_FOUND;
        return res
            .status(status)
            .json(new ResponseModel(status, error.message, error));
    }
}

module.exports = {
    insert,
    getAll,
    getById,
    deleteById,
    update,
    getPaging,
};
