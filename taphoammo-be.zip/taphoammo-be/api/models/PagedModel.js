module.exports = class PagedModel {
    constructor(pageIndex, pageSize, count, data) {
        pageIndex = Number.parseInt(pageIndex);
        pageSize = Number.parseInt(pageSize);
        let totalPages = count < pageSize ? 1 : Math.ceil(count / pageSize);
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
        this.totalPages = totalPages;
        this.totalCount = count;
        this.data = data;
    }
};