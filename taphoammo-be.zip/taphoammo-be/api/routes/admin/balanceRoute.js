const express = require('express');
const router = express.Router();
const middlewares = require('../middlewares');
const balanceController = require('../../controllers/balanceController');
const {
    editBalance,
    confirmDepositWithCode,
    createDepositCode,
    getPaging,
    userWithdraw,
    changeTractionStatus
} = require('../../middlewares/balanceMiddlewares');

router.post('/update', editBalance, middlewares.authorizeAdmin, balanceController.editBalance);

router.post('/create-deposit-code', createDepositCode, middlewares.authorize, balanceController.createDepositCode);

router.post('/update-with-code', confirmDepositWithCode, middlewares.authorizeAdmin, balanceController.confirmDepositWithCode);

router.post('/user-withdraw', userWithdraw, middlewares.authorize, balanceController.userWithdraw);

router.get('/deposit-histories', getPaging, middlewares.authorize, balanceController.getDepositHistories);

router.get('/withdraw-histories', getPaging, middlewares.authorize, balanceController.getWithdrawHistories);

router.post('/change-status', changeTractionStatus, middlewares.authorizeAdmin, balanceController.changeTractionStatus);

module.exports = router;