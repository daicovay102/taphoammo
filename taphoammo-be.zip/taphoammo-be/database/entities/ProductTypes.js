require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const slug = require('mongoose-slug-generator');
mongoose.plugin(slug);
const { Schema } = mongoose;

let product_typeSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    name: {
        type: String,
        unique: true,
        required: true
    },
    slug: { 
        type: String, 
        slug: "name",
        unique: true
    },
    business_typeId: {
        type: Schema.Types.ObjectId,
        ref: 'Business_types',
        required: true
    },
    shop_typeId: {
        type: Schema.Types.ObjectId,
        ref: 'Shop_types',
        required: true
    },
    discount_percent: {
        type: Number,
        default: 0,
        required: true
    },
    status: {
        type: Number,
        default: 1
    }
}, {
    versionKey: false,
    timestamps: true
});
product_typeSchema.plugin(mongoose_delete, { deletedAt : true, overrideMethods: 'all'});
module.exports = mongoose.model('Product_types', product_typeSchema)
