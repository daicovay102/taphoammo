const ProductUploads = require('../../database/entities/ProductUploads');
const ProductImports = require('../../database/entities/ProductImports');
const Products = require('../../database/entities/Products');
const Shops = require('../../database/entities/Shops');
const PagedModel = require('../models/PagedModel');
const ResponseModel = require('../models/ResponseModel');
const { SHOP_STATUS, PRODUCT_IMPORT_STATUS } = require('../../constants/enum');
const AdmZip = require('adm-zip');
const { Types } = require('mongoose');
const fs = require('fs');
const path = require('path');

async function insert(req, res) {
    try {
        const { shopId, productId } = req.body;
        const shop = await Shops.findById(shopId);
        if (!shop || shop.status !== SHOP_STATUS.Accepted) {
            let response = new ResponseModel(-1, 'Gian hàng của bạn chưa được duyệt!', null);
            return res.json(response);
        }

        const product = await Products.findOne({ '$and': [{ '_id': productId }, { 'shopId': shopId }] });
        if (!product) {
            let response = new ResponseModel(-1, 'Sản phẩm của bạn không nằm trong gian hàng này.', null);
            return res.json(response);
        }

        if (!req.file) {
            let response = new ResponseModel(-2, 'Bạn chưa chọn file để tải lên!', null);
            return res.json(response);
        }

        const uploadResult = {
            total: 0,
            success: 0,
            error: 0
        };

        try {
            // xu ly file zip
            const zip = new AdmZip(req.file.path, {});
            const folders = zip.getEntries().filter(x => x.isDirectory && new RegExp('^[^/]*/[^/]*$').test(x.entryName));
            uploadResult.total = folders.length;
            const folderNames = folders.map(x => x.entryName.replace('/', '').toLowerCase());
            const exists = await ProductImports.find({ name: { $in: folderNames } });
            const destination = req.file.destination;
            zip.extractAllTo(destination, true, false, '');

            // kiem tra thu muc va map data
            const createProductImports = [];
            const productUploadId = new Types.ObjectId();
            folderNames.forEach(name => {
                const isExist = exists.find(x => x.name === name);
                if (isExist) {
                    uploadResult.error = uploadResult.error + 1;
                } else {
                    createProductImports.push({
                        createdBy: req.userId,
                        name,
                        filePath: `${destination}/${name}`,
                        productId: product._id,
                        productTypeId: product.productTypeId,
                        productUploadId,
                        shopId: shop._id,
                        status: PRODUCT_IMPORT_STATUS.PENDING
                    });
                    uploadResult.success = uploadResult.success + 1;
                }
            });

            // tao product upload, product import, tang so luong product
            await Promise.all([
                ProductUploads.create({
                    _id: productUploadId,
                    createdBy: req.userId,
                    nameFile: req.file.filename,
                    name: product.name,
                    filePath: req.file.path,
                    productId: product._id,
                    shopId: shop._id,
                    result: uploadResult
                }),
                ...(createProductImports.length ? [ProductImports.create(createProductImports)] : []),
                ...(uploadResult.success > 0 ? [Products.findByIdAndUpdate(productId, { $inc: { quantity: uploadResult.success } })] : [])
            ]);
        } catch (e) {
            console.log(`Something went wrong. ${e}`);
        }
        return res.json(new ResponseModel(1, 'Success', uploadResult));
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }
}


async function getPaging(req, res) {
    try {
        const pageSize = req.query.pageSize ? parseInt(req.query.pageSize) : 10;
        const pageIndex = req.query.pageIndex ? parseInt(req.query.pageIndex) : 1;

        const searchObj = {};
        searchObj.shopId = req.query.shopId;
        let products = await ProductUploads.find(searchObj)
            .skip(pageSize * pageIndex - pageSize)
            .limit(pageSize)
            .populate('shopId shopId.business_typeId')
            .sort({
                createdAt: 'desc',
            });
        const count = await ProductUploads.find(searchObj).countDocuments();
        let pagedModel = new PagedModel(pageIndex, pageSize, count, products);
        res.json(pagedModel);
    } catch (error) {
        let response = new ResponseModel(404, error.message, error);
        res.status(404).json(response);
    }

}

async function getAll(req, res) {
    const products = await ProductUploads.find({ shopId: req.query.shopId }).sort({ createdAt: 'desc', });
    res.json(products);

}

module.exports = {
    insert,
    getAll,
    getPaging
};
