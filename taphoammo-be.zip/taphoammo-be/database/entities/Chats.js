require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');


const { Schema } = mongoose;

let chatSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    UserTo: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    messages: [{
        UserSend: {
            type: Schema.Types.ObjectId,
            ref: 'Users',
            required: true
        },
        message : {type: String, required: true},
        time : {type: Date, required: true}
    }]
}, {
    versionKey: false,
    timestamps: true
});
chatSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Chats', chatSchema)
