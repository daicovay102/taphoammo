module.exports.TOKEN_TYPE = Object.freeze({
    AccessToken: 1,
    RefreshToken: 2,
    ForgotPasswordToken: 3,
    EmailVerifyToken: 4
});

module.exports.USER_ROLE = Object.freeze({
    Admin: 1,
    Buyer: 2,
    Seller: 3
});

module.exports.PRODUCT_STATUS = Object.freeze({
    Pending: 0,
    Accepted: 1,
    Rejected: 2
});

module.exports.SHOP_STATUS = Object.freeze({
    Pending: 0,
    Accepted: 1,
    Rejected: 2
});

module.exports.SERVICE_STATUS = Object.freeze({
    Pending: 0,
    Accepted: 1,
    Rejected: 2
});

module.exports.ORDER_STATUS = Object.freeze({
    DOI_CHAP_THUAN: 0,
    DANG_THUC_HIEN: 1,
    TAM_GIU_TIEN: 2,
    HOAN_THANH: 3,
    HUY: 4,
    THAT_BAI: 5,
    KHIEU_NAI: 6
});

module.exports.SELLER_STATUS = Object.freeze({
    Pending: 0,
    Accepted: 1,
    Complain: 2,
    Canceled: 3
});

module.exports.PRODUCT_SORT = Object.freeze({
    PHO_BIEN: 0,
    GIA_TANG: 1,
    GIA_GIAM: 2
});

module.exports.DISCOUNT_TYPE = Object.freeze({
    PHAN_TRAM: 0,
    SO_TIEN: 1
});

module.exports.TRANSACTION_TYPE = Object.freeze({
    ORDER: 0,
    RUT_TIEN: 1,
    NAP_TIEN: 2,
    PHI_HOA_HONG_CUA_SAN: 3 // so tien hoa hong cua san khi hoan thanh order
});

module.exports.TRANSACTION_STATUS = Object.freeze({
    PENDING: 1,
    COMPLETE: 2,
    CANCELED: 3
});

module.exports.PRODUCT_IMPORT_STATUS = Object.freeze({
    PENDING: 0,
    SOLD: 1
});