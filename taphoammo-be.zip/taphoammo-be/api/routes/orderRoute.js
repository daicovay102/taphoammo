const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const middlewares = require('./middlewares');
const {
    createOrderValidator,
    getByIdValidator,
    getPagingValidator,
    updateValidator
} = require('../middlewares/orderMiddlewares');

router.post('/insert', createOrderValidator, middlewares.authorize, orderController.createOrder);

router.get('/getAll', middlewares.authorizeAdmin, orderController.getAll);

router.get('/getPaging', getPagingValidator, middlewares.authorize, orderController.getPaging);

router.get('/getById/:id', getByIdValidator, middlewares.authorize, orderController.getById);

router.delete('/delete/:id', getByIdValidator, middlewares.authorizeAdmin, orderController.deleteById);

router.patch('/update', updateValidator, middlewares.authorize, orderController.update);

module.exports = router;