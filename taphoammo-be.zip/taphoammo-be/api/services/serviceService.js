const Services = require('../../database/entities/Services');
const { isValidObjectId } = require('mongoose');

exports.insert = async (payload, userId) => {
    const dataInsert = { ...payload, createdBy: userId };
    const dataResult = new Services(dataInsert);
    return await dataResult.save();
};

exports.getAll = async (userId) => {
    return Services.find({ createdBy: userId }).sort({ createdAt: 'desc', });
};

exports.getById = async (id) => {
    return await Services.findOneWithDeleted({ _id: isValidObjectId(id) ? id : null });
};

exports.checkNameServiceByShop = async (name, shopId) => {
    return Services.findOne({ '$and': [{ 'name': name }, { 'shopId': isValidObjectId(shopId) ? shopId : null }] });
};

exports.checkNameServiceUpdate = async (id, name) => {
    let service = await Services.findOneWithDeleted({ _id: isValidObjectId(id) ? id : null });
    return Services.findOne({ '$and': [{ '_id': { '$nin': id } }, { 'name': name }, { 'shopId': service.shopId }] });
};

exports.deleteById = async (id, userId) => {
    return Services.deleteOne({ '$and': [{ _id: id }, { createdBy: userId }] });
};

exports.update = async (id, payload, userId) => {
    return Services.findOneAndUpdate(
        { '$and': [{ _id: id }, { createdBy: userId }] },
        { updatedAt: Date.now(), ...payload },
        { new: true }
    );
};

exports.getPaging = async (query, userId) => {
    let pageSize = query.pageSize || 10;
    let pageIndex = query.pageIndex || 1;

    let searchObj = { createdBy: userId };
    if (query.name) {
        searchOb.name = { $regex: '.*' + query.name + '.*' };
    }
    if (query.shopId) {
        searchObj.shopId = isValidObjectId(query.shopId) ? query.shopId : null;
    }
    let data = await Services.find(searchObj)
        .skip(pageSize * pageIndex - pageSize)
        .limit(parseInt(pageSize))
        .sort({
            createdAt: 'desc',
        });
    const count = await Services.find(searchObj).countDocuments();

    return { pageIndex, pageSize, count, data };
};