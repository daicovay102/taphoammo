require("../database");
const mongoose = require("mongoose");
const mongoose_delete = require("mongoose-delete");
const { USER_ROLE } = require("../../constants/enum");
const { Schema } = mongoose;

let userSchema = new Schema(
  {
    userName: {
      type: String,
    },
    password: {
      type: String,
      required: true,
    },
    balance: {
      type: Number,
      default: 0,
    },
    avatar: {
      type: String,
    },
    fullName: {
      type: String,
      default: "",
    },
    phoneNumber: {
      type: String,
      default: "",
    },
    email: {
      type: String,
      default: "",
      required: true,
      unique: true,
    },
    facebook: {
      type: String,
      default: "",
    },
    forgotPasswordToken: {
      type: String,
      default: "",
    },
    role: {
      type: Number,
      require: true,
      default: USER_ROLE.Buyer,
    },
    telegram: {
      status: { type: Number, default: 0 },
      group_id: { type: String, default: "" },
    },
    google_2fa: {
      status: { type: Number, default: 0 },
      secret: { type: String, default: "" },
    },
    token_api: {
      status: { type: Number, default: 0 },
      token: { type: String, default: "" },
    },
    isOnline: {
      type: Boolean,
      default: false,
    },
    status: {
      type: Number,
      default: 1,
    },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);
userSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: "all" });
module.exports = mongoose.model("Users", userSchema);
