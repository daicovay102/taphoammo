const { validate, checkObjectIdOptions } = require('../../utilities/validation');
const { checkSchema } = require('express-validator');

const createValidator = validate(
    checkSchema(
        {
            UserTo: {
                trim: true,
                custom: { options: checkObjectIdOptions('UserTo') },
            },
        },
        ['body']
    )
);
const messageValidator = validate(
    checkSchema(
        {
            chatId: {
                trim: true,
                custom: { options: checkObjectIdOptions('chatId') },
            },
            message: { isString: { options: { min: 0 } }, optional: false },
        },
        ['body']
    )
);
module.exports = {
    createValidator,
    messageValidator
};