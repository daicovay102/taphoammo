const Users = require('../../database/entities/Users');
const { config } = require('dotenv');
const { TOKEN_TYPE } = require('../../constants/enum');
const { signToken } = require('../../utilities/jwt');
const ReFreshTokens = require('../../database/entities/ReFreshTokens');
const { hashPassword } = require('../../utilities/cryto');
const { default: mongoose, isValidObjectId } = require('mongoose');
const { pickBy, identity } = require('lodash');
const ErrorWithStatus = require('../models/Errors');
const { HTTP_STATUS } = require('../../constants/httpStatus');
const sendResetEmail = require('../../utilities/emailUtils');
const axios = require('axios');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const { verify2FA } = require('../../utilities/authentication2FA');

config();
const signAccessToken = ({ _id, role }) => {
    return signToken({
        payload: {
            user: {
                _id,
                role,
            },
            tokenType: TOKEN_TYPE.AccessToken,
        },
        privateKey: process.env.JWT_SECRET_ACCESS_TOKEN,
        options: {
            expiresIn: process.env.ACCESS_TOKEN_EXPIRES_IN,
        },
    });
};

const signRefreshToken = ({ _id, role }) => {
    return signToken({
        payload: {
            user: {
                _id,
                role,
            },
            tokenType: TOKEN_TYPE.RefreshToken,
        },
        privateKey: process.env.JWT_SECRECT_REFRSH_TOKEN,
        options: {
            expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN,
        },
    });
};

const signAccessAndRefreshToken = async ({ _id, role }) => {
    return await Promise.all([
        signAccessToken({ _id, role }),
        signRefreshToken({ _id, role }),
    ]);
};

const signForgotPasswordToken = async (userId) => {
    return signToken({
        payload: {
            userId,
            tokenType: TOKEN_TYPE.ForgotPasswordToken,
        },
        privateKey: process.env.JWT_SECRECT_FORGOT_PASS_WORK_TOKEN,
        options: {
            expiresIn: process.env.FORGOT_PASS_WORK_TOKEN_EXPIRES_IN,
        },
    });
};

exports.register = async (payload) => {
    const dataUser = { ...payload, password: hashPassword(payload.password) };
    const userEntity = new Users(dataUser);
    const newUser = await userEntity.save();
    const [accessToken, refreshToken] = await signAccessAndRefreshToken({
        _id: newUser._id.toString(),
        role: newUser.role,
    });
    const refreshTokenEntry = new ReFreshTokens({
        userId: newUser._id,
        token: refreshToken,
    });
    await refreshTokenEntry.save();
    return {
        user: {
            id: newUser._id,
            email: newUser.email,
            role: newUser.role,
            userName: newUser.userName,
            phoneNumber: newUser.phoneNumber,
            avatar: newUser.avatar,
            fullName: newUser.fullName,
        },
        accessToken,
        refreshToken,
    };
};

exports.login = async (user, userToken) => {
    const { _id, role, google_2fa } = user;

    if (google_2fa.status) {
        verify2FALogin(userToken, google_2fa);
    }
    const [accessToken, refreshToken] = await signAccessAndRefreshToken({
        _id: _id.toString(),
        role,
    });
    const refreshTokenEntry = new ReFreshTokens({
        userId: _id,
        token: refreshToken,
    });
    await refreshTokenEntry.save();
    return {
        user: {
            id: user._id,
            email: user.email,
            role: user.role,
            userName: user.userName,
            phoneNumber: user.phoneNumber,
            avatar: user.avatar,
            fullName: user.fullName,
        },
        accessToken,
        refreshToken,
    };
};

const verify2FALogin = (userToken, google_2fa) => {
    const { secret } = google_2fa;
    if (!userToken) {
        throw new ErrorWithStatus({
            message: 'Vui lòng nhập mã đăng nhập 2FA.',
            status: HTTP_STATUS.UNAUTHORIZED,
        });
    }
    const isValid = verify2FA(secret, userToken);
    if (!isValid) {
        throw new ErrorWithStatus({
            message: 'Mã đăng nhập 2FA không hợp lệ',
            status: HTTP_STATUS.UNAUTHORIZED,
        });
    }
};

exports.logout = async (refreshToken) => {
    await ReFreshTokens.deleteOne({ token: refreshToken });
};

exports.checkEmailExits = async (email) => {
    const user = await Users.findOne({ email });
    return Boolean(user);
};

exports.insert = async (payload) => {
    const updateModel = setConfigModel(payload);
    const dataUser = {
        ...updateModel,
        password: hashPassword(payload.password),
    };
    const newUser = new Users(dataUser);
    return await newUser.save();
};

exports.getPaging = async (query) => {
    const pageSize = parseInt(query.pageSize) || 10;
    const pageIndex = parseInt(query.pageIndex) || 1;

    const queryParams = {
        email: (query.email || '').trim(),
        searchText: (query.searchText || '').trim(),
        role: Number(query.role) || null,
        phoneNumber: (query.phoneNumber || '').trim(),
    };

    const searchObj = setSearchObj(queryParams);

    const usersQuery = Users.find(searchObj)
        .sort({ createdAt: 'desc' })
        .skip((pageIndex - 1) * pageSize)
        .limit(pageSize);

    const [data, count] = await Promise.all([
        usersQuery.exec(),
        Users.countDocuments(searchObj),
    ]);
    return { pageIndex, pageSize, count, data };
};

const setSearchObj = (queryParams) => {
    const searchObj = {};

    if (queryParams.email) {
        searchObj.email = queryParams.email;
    }
    if (queryParams.role !== null) {
        searchObj.role = queryParams.role;
    }
    if (queryParams.phoneNumber) {
        searchObj.phoneNumber = queryParams.phoneNumber;
    }

    if (queryParams.searchText) {
        const searchRegex = new RegExp(queryParams.searchText, 'i');
        searchObj.$or = [
            { fullName: { $regex: searchRegex } },
            { userName: { $regex: searchRegex } },
            {
                _id: mongoose.Types.ObjectId.isValid(queryParams.searchText)
                    ? mongoose.Types.ObjectId(queryParams.searchText)
                    : null,
            },
        ];
    }

    return searchObj;
};

exports.update = async (payload, userId) => {
    const updateModel = setConfigModel(payload);
    validateUpdate(updateModel, userId);
    const updateData = { updatedAt: Date.now(), ...updateModel };
    const updatedUser = await Users.findByIdAndUpdate(userId, updateData, {
        new: true,
    });
    if (!updatedUser) {
        throw new ErrorWithStatus({
            message: 'Không tìm thấy người dùng',
            status: HTTP_STATUS.NOT_FOUND,
        });
    }
};

const validateUpdate = (updateModel, userId) => {
    if (Object.keys(updateModel).length === 0) {
        throw new ErrorWithStatus({
            message: 'Vui lòng nhập dữ liệu để cập nhập.',
            status: HTTP_STATUS.BAD_REQUEST,
        });
    }
    if (!userId || !isValidObjectId(userId)) {
        throw new ErrorWithStatus({
            message: 'UserId không hợp lệ.',
            status: HTTP_STATUS.BAD_REQUEST,
        });
    }
};

const setConfigModel = (payload) => {
    const model = {
        userName: payload.userName ? payload.userName.toString() : null,
        avatar: payload.avatar ? payload.avatar.toString() : null,
        fullName: payload.fullName ? payload.fullName.toString() : null,
        phoneNumber: payload.phoneNumber ? payload.phoneNumber.toString() : null,
        email: payload.email ? payload.email.toString() : null,
        role: Number(payload.role) || null,
        balance: payload.balance ? payload.balance.toString() : null,
    };
    const filteredModel = pickBy(model, identity);
    return filteredModel;
};

exports.forgotPassword = async (user) => {
    const { _id, email } = user;
    const userId = _id.toString();
    const forgotPasswordToken = await signForgotPasswordToken(userId);
    await Users.findByIdAndUpdate(userId, { forgotPasswordToken });

    // Send the email with the reset link
    const resetLink = `${process.env.WEB_RESET_PASSWORD_BASE_URL}/?token=${forgotPasswordToken}`;
    await sendResetEmail(email, resetLink);
};

exports.resetPassword = async (userId, password) => {
    await Users.findByIdAndUpdate(userId, {
        password: hashPassword(password),
        updatedAt: Date.now(),
        forgotPasswordToken: '',
    });
};

exports.changePassword = async (userId, password) => {
    const updateData = {
        password: hashPassword(password),
        updatedAt: Date.now(),
    };
    await Users.findByIdAndUpdate(userId, updateData);
};

exports.getMe = async (userId) => {
    const user = await Users.findById(userId, {
        password: 0,
        forgotPasswordToken: 0,
        token_api: 0,
        status: 0,
    });
    return user;
};

exports.oauth = async (code) => {
    const { id_token, access_token } = await getOathGoogleToken(code);
    const userInfo = await getGoogleUserInfo(id_token, access_token);
    const user = await Users.findOne({
        email: userInfo,
    });
    if (user) {
        //login
        const [accessToken, refreshToken] = await signAccessAndRefreshToken({
            _id: user._id.toString(),
            role: user.role,
        });
        const refreshTokenEntry = new ReFreshTokens({
            userId: user._id,
            token: refreshToken,
        });
        await refreshTokenEntry.save();
        return {
            accessToken,
            refreshToken,
            isNewUser: 0,
        };
    }
    // register
    const password = Math.random().toString(36).substring(2, 15);
    const data = await this.register({
        email: userInfo.email,
        userName: userInfo.name,
        avatar: userInfo.picture,
        password,
        confirm_password: password,
    });
    return { ...data, isNewUser: 0 };
};

const getOathGoogleToken = async (code) => {
    const body = {
        code,
        client_id: process.env.GOOGLE_CLIENT_ID,
        client_secret: process.env.GOOGLE_CLIENT_SECRET,
        redirect_uri: process.env.GOOGLE_REDIRECT_URI,
        grant_type: 'authorization_code',
    };
    const { data } = await axios.post(
        'https://oauth2.googleapis.com/token',
        body,
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        }
    );
    return data;
};

const getGoogleUserInfo = async (access_token, id_token) => {
    const { data } = await axios.get(
        'https://www.googleapis.com/oauth2/v1/userinfo',
        {
            params: {
                access_token,
                alt: 'json',
            },
            headers: {
                Authorization: `Bearer ${id_token}`,
            },
        }
    );
    return data;
};

exports.enable2FA = async (userId) => {
    const secret = speakeasy.generateSecret();
    secret.otpAuthUrl = {
        secret: secret.base32,
        label: process.env.APP_LABEL,
        algorithm: 'sha1',
    };
    const [user, qrCodeDataUrl] = await Promise.all([
        Users.findOneAndUpdate(
            { _id: userId },
            {
                $set: {
                    updatedAt: Date.now(),
                    'google_2fa.secret': secret.base32,
                },
            },
            { new: false }
        ),
        generateQRCode(secret.otpauth_url),
    ]);
    return { qrCodeDataUrl };
};

exports.verify2FA = async (userId) => {
    await Users.findOneAndUpdate(
        { _id: userId },
        {
            $set: {
                updatedAt: Date.now(),
                'google_2fa.status': 1,
            },
        },
        { new: false }
    );
};

const generateQRCode = async (otpAuthUrl) => {
    return new Promise((resolve, reject) => {
        qrcode.toDataURL(otpAuthUrl, (err, dataUrl) => {
            if (err) {
                reject(err);
            } else {
                resolve(dataUrl);
            }
        });
    });
};

exports.disable2Fa = async (userId) => {
    await Users.findOneAndUpdate(
        { _id: userId },
        {
            $set: {
                updatedAt: Date.now(),
                google_2fa: {
                    status: 0,
                    secret: '',
                },
            },
        },
        { new: false }
    );
};
exports.updateIsOnline = async (userId, status) => {
    await Users.updateOne({ _id: userId }, { $set: { isOnline: status } });
};
exports.updateChatIdTelegram = async (userId, status, group_id) => {
    await Users.updateOne(
        { _id: userId },
        { $set: { 'telegram.status': status, 'telegram.group_id': group_id } }
    );
};
