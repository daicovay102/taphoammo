const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();
const morgan = require('morgan');
const cors = require('cors');
const app = express();

const http = require('http').Server(app);
const io = require('socket.io')(http);
global.io = io;
const port = process.env.PORT;

app.use(morgan('combined'));
app.use(cors());
app.options('*', cors());

/*const options = {
	definition: {
		openapi: "3.1.0",
		info: {
			title: "TaphoaMmO",
			version: "1.0.0",
			description: "API taphoammo",
		},
		servers: [
			{
				url: `http://localhost:${port}`,
			},
		],
	},
	apis: ["./api/routes/*.js"],
};

const specs = swaggerJsDoc(options);
app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(specs));*/

const socket = require('./api/socket')(io);
const telegram = require('./api/telegram');

const userRoute = require('./api/routes/userRoute');
const uploadRoute = require('./api/routes/uploadRoute');
const productRoute = require('./api/routes/productRoute');
const productUploadRoute = require('./api/routes/productUploadRoute');
const productImportRoute = require('./api/routes/productImportRoute');
const shopRoute = require('./api/routes/shopRoute');
const businessTypeRoute = require('./api/routes/businessTypeRoute');
const shopTypeRoute = require('./api/routes/shopTypeRoute');
const productTypeRoute = require('./api/routes/productTypeRoute');
const shopReviewRoute = require('./api/routes/admin/shopReviewRoute');
const orderRoute = require('./api/routes/orderRoute');
const shopEvaluationRoute = require('./api/routes/shopEvaluationRoute');
const complainRoute = require('./api/routes/complainRoute');
const serviceRoute = require('./api/routes/serviceRoute');
const chatRoute = require('./api/routes/chatRoute');
const discountRoute = require('./api/routes/discountRoute');
const balanceRoute = require('./api/routes/admin/balanceRoute');
require('./api/routes/cronJob');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//import routes
app.use('/api/user', userRoute);
app.use('/api/upload', uploadRoute);
app.use('/api/product', productRoute);
app.use('/api/product-upload', productUploadRoute);
app.use('/api/product-import', productImportRoute);
app.use('/api/shop', shopRoute);
app.use('/api/businesstype', businessTypeRoute);
app.use('/api/shoptype', shopTypeRoute);
app.use('/api/producttype', productTypeRoute);
app.use('/api/service', serviceRoute);
app.use('/api/shop-review', shopReviewRoute);
app.use('/api/order', orderRoute);
app.use('/api/shop-evaluation', shopEvaluationRoute);
app.use('/api/complain', complainRoute);
app.use('/api/chat', chatRoute);
app.use('/api/discount', discountRoute);
app.use('/api/balance', balanceRoute);

// Public Folder
app.use('/uploads', express.static(path.join(__dirname, '/uploads/images')));

http.listen(port, () => {
    console.log(`Socket.IO server running at http://localhost:${port}/`);
});
