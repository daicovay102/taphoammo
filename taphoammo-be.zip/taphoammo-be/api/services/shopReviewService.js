const ShopReviewHistories = require("../../database/entities/ShopReviewHistories");
const Shops = require("../../database/entities/Shops");
const { isValidObjectId } = require("mongoose");

const reviewShop = async (createdBy, status, shopId) => {
  const [history] = await Promise.all([
    ShopReviewHistories.create({
      createdBy,
      status,
      shopId,
    }),
    Shops.findByIdAndUpdate(shopId, { $set: { status } }),
  ]);
  return history;
};

const getAll = async () => {
  return ShopReviewHistories.find({})
    .populate("createdBy shopId")
    .sort({ createdAt: "desc" });
};

const getPaging = async (query, userId) => {
  const pageSize = Number.parseInt(query.pageSize) || 10;
  const pageIndex = Number.parseInt(query.pageIndex) || 1;

  const searchObj = {};

  if (query.shopId) {
    searchObj.shopId = isValidObjectId(query.shopId) ? query.shopId : null;
  }
  if (userId) {
    searchObj.createdBy = isValidObjectId(userId) ? userId : null;
  }
  const [data, count] = await Promise.all([
    ShopReviewHistories.find(searchObj)
      .skip(pageSize * pageIndex - pageSize)
      .limit(pageSize)
      .sort({ createdAt: "desc" }),
    ShopReviewHistories.countDocuments(searchObj),
  ]);
  return { pageIndex, pageSize, count, data };
};

const getById = async (id) => {
  return await ShopReviewHistories.findOneWithDeleted({
    _id: isValidObjectId(id) ? id : null,
  });
};

module.exports = { reviewShop, getAll, getPaging, getById };
