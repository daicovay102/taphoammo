const { isValidObjectId } = require('mongoose');
const Shops = require('../../database/entities/Shops');
const { isNotNullAndUndefined } = require('../../utilities/validation');

exports.checkShopById = async (shopId) => {
    return Shops.findOne({
        $and: [{ _id: isValidObjectId(shopId) ? shopId : null }],
    });
};

exports.insert = async (payload, userId) => {
    const dataInsert = { ...payload, createdBy: userId };
    const insertEntity = new Shops(dataInsert);
    return await insertEntity.save();
};

exports.checkNameShopUpdate = async (id, name) => {
    return Shops.findOne({ $and: [{ _id: { $nin: id } }, { name: name }] });
};

exports.update = async (id, payload, userId) => {
    return Shops.findOneAndUpdate(
        { $and: [{ _id: id }, { createdBy: userId }] },
        { updatedAt: Date.now(), ...payload },
        { new: true }
    );
};

exports.getPaging = async (query) => {
    let pageSize = query.pageSize || 10;
    let pageIndex = query.pageIndex || 1;

    let searchObj = { deleted: false };
    if (query.name) {
        searchObj.name = { $regex: new RegExp(query.name, 'i') };
    }
    if (isNotNullAndUndefined(query.status)) {
        searchObj.status = status;
    }

    let data = await Shops.find(searchObj)
        .skip(pageSize * pageIndex - pageSize)
        .limit(parseInt(pageSize))
        .populate('business_typeId shop_typeId product_typeId')
        .sort({
            createdAt: 'desc',
        });
    const count = await Shops.find(searchObj).countDocuments();

    return { pageIndex, pageSize, count, data };
};

exports.getAll = async () => {
    return Shops.find({})
        .populate('business_typeId shop_typeId product_typeId')
        .sort({ createdAt: 'desc' });
};

exports.getById = async (id) => {
    const result = await Shops.findOneWithDeleted(
        {
            _id: isValidObjectId(id) ? id : null,
        },
    ).populate(
        'createdBy slug business_typeId shop_typeId product_typeId'
    );

    return {
        userName: result.createdBy.userName,
        shop: result.name,
        business_typeId: result.business_typeId,
        shop_typeId: result.shop_typeId,
        product_typeId: result.product_typeId,
        product: result.product,
    };
};

exports.deleteById = async (id, userId) => {
    return Shops.deleteOne({ $and: [{ _id: id }, { createdBy: userId }] });
};
