require("../database");
const mongoose = require("mongoose");
const mongoose_delete = require("mongoose-delete");
const slug = require("mongoose-slug-generator");
mongoose.plugin(slug);
const { Schema } = mongoose;

const refreshTokenSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: "Users",
      required: true,
    },
    token: {
      type: String,
      required: true,
    },
  },
  {
    versionKey: false,
    timestamps: true,
  }
);
refreshTokenSchema.plugin(mongoose_delete, {
  deletedAt: true,
  overrideMethods: "all",
});
module.exports = mongoose.model("RefreshToken", refreshTokenSchema);
