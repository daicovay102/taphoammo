require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const slug = require('mongoose-slug-generator');
mongoose.plugin(slug);
const { Schema } = mongoose;

let shop_typeSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    name: {
        type: String,
        unique: true,
        required: true
    },
    slug: { 
        type: String, 
        slug: "name",
        unique: true
    },
    business_typeId: {
        type: Schema.Types.ObjectId,
        ref: 'Business_types',
        required: true
    },
    status: {
        type: Number,
        default: 1
    }
}, {
    versionKey: false,
    timestamps: true
});
shop_typeSchema.plugin(mongoose_delete, { deletedAt : true, overrideMethods: 'all'});
module.exports = mongoose.model('Shop_types', shop_typeSchema)
