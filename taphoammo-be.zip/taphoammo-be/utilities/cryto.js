const { config } = require("dotenv");
const { createHash } = require("crypto");
config();
/**
 * Returns a SHA256 hash using SHA-2 for the given `content`.
 *
 * @see https://en.wikipedia.org/wiki/SHA-2
 *
 * @param {String} content
 *
 * @returns {String}
 */
exports.sha256 = (content) => {
  return createHash("sha256").update(content).digest("hex");
};

exports.hashPassword = (password) => {
  return this.sha256(password + process.env.PASSWORD_SECRET);
};
