require('../database');
const mongoose = require('mongoose');
const mongoose_delete = require('mongoose-delete');
const { Schema } = mongoose;

const shopEvaluationSchema = new Schema({
    createdBy: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: true
    },
    shopId: {
        type: Schema.Types.ObjectId,
        ref: 'Shops',
        required: true
    },
    content: {
        type: String, required: true, trim: true
    },
    reviewPoint: {
        type: Number, required: true, min: 0, max: 5
    }
}, {
    versionKey: false,
    timestamps: true
});
shopEvaluationSchema.plugin(mongoose_delete, { deletedAt: true, overrideMethods: 'all' });
module.exports = mongoose.model('Shop_evaluations', shopEvaluationSchema);
