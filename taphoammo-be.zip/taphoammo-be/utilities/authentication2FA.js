const speakeasy = require("speakeasy");
exports.verify2FA = (secret, usertoken) => {
  return speakeasy.totp.verify({
    secret: secret,
    encoding: "base32",
    token: usertoken,
    window: 0,
  });
};
