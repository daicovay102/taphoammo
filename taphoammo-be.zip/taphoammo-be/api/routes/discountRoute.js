const express = require('express');
const router = express.Router();
const discountController = require('../controllers/discountController');
const middlewares = require('./middlewares');
const {
    createValidator,
    getPagingValidator,
    getByIdValidator,
    updateValidator
} = require('../middlewares/discountMiddlewares');

router.post('/insert', createValidator, middlewares.authorizeAdmin, discountController.insert);

router.get('/getAll', middlewares.authorizeAdmin, discountController.getAll);

router.get('/getPaging', getPagingValidator, middlewares.authorizeAdmin, discountController.getPaging);

router.get('/getById/:id', getByIdValidator, middlewares.authorize, discountController.getById);

router.delete('/delete/:id', getByIdValidator, middlewares.authorizeAdmin, discountController.deleteById);

router.patch('/update', updateValidator, middlewares.authorizeAdmin, discountController.update);

module.exports = router;