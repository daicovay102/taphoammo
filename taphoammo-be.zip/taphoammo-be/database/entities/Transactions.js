require('../database');
const mongoose = require('mongoose');
const { TRANSACTION_TYPE, TRANSACTION_STATUS } = require('../../constants/enum');
const { Schema } = mongoose;

const transactionSchema = new Schema({
    // su dung khi order
    sellerId: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: false
    },
    orderId: {
        type: Schema.Types.ObjectId,
        ref: 'Orders',
        required: false
    },
    buyerId: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: false
    },
    value: {
        type: Number,
        required: true
    },
    type: {
        type: Number,
        required: true,
        default: TRANSACTION_TYPE.ORDER,
        enum: Object.values(TRANSACTION_TYPE)
    },
    // su dung khi nap tien, rut tien
    adminId: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: false
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'Users',
        required: false
    },
    depositCode: {
        type: String,
        required: false
    },
    status: {
        type: Number,
        required: true,
        default: TRANSACTION_STATUS.PENDING,
        enum: Object.values(TRANSACTION_STATUS)
    }
}, {
    versionKey: false,
    timestamps: true
});

module.exports = mongoose.model('Transactions', transactionSchema);
