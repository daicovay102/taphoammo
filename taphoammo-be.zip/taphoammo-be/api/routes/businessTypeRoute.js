const express = require('express');
const router = express.Router();
const businessTypeController = require('../controllers/businessTypeController');
const middlewares = require('./middlewares');

router.post('/insert', middlewares.authorizeAdmin, businessTypeController.insert);
router.put('/update/:id', middlewares.authorizeAdmin, businessTypeController.update);
router.delete('/delete/:id', middlewares.authorizeAdmin, businessTypeController.deleteById);
router.delete('/deleteMany', middlewares.authorizeAdmin, businessTypeController.deleteMany);
router.get('/getAll', businessTypeController.getAll);
router.get('/getById/:id', businessTypeController.getById);
router.get('/getPaging', businessTypeController.getPaging);

module.exports = router;